<?php
/**
 * Plugin Name: Ship Restrict
 * Plugin URI: https://shiprestrict.com
 * Description: Restrict products from shipping to specific US locations. Free: 2 rules & 2 products. Pro: Unlimited restrictions with license key.
 * Version: 1.3.0
 * Author: UpNorth Media
 * Author URI: https://upnorthmedia.co
 * Text Domain: ship-restrict
 * License: GPLv2 or later
 * Requires at least: 5.6
 * Requires PHP: 7.2
 * WC requires at least: 5.0
 * WC tested up to: 9.8
 *
 * @package Ship_Restrict_Pro
 */


// Cache and rate limiting constants
if ( ! defined( 'SPSR_CACHE_DURATION' ) ) {
    define( 'SPSR_CACHE_DURATION', 86400 ); // 24 hours
}
if ( ! defined( 'SPSR_RATE_LIMIT_MAX' ) ) {
    define( 'SPSR_RATE_LIMIT_MAX', 10 );
}
if ( ! defined( 'SPSR_RATE_LIMIT_WINDOW' ) ) {
    define( 'SPSR_RATE_LIMIT_WINDOW', 300 ); // 5 minutes
}

defined('ABSPATH') || exit;

/**
 * Main plugin class
 */
class APSR_Pro {
    /**
     * Plugin version
     *
     * @var string
     */
    const VERSION = '1.3.0';

    /**
     * Plugin singleton instance
     *
     * @var APSR_Pro
     */
    protected static $_instance = null;

    /**
     * Flag to prevent duplicate validation messages
     *
     * @var bool
     */
    private $validation_run = false;

    /**
     * Main plugin instance
     *
     * @return APSR_Pro
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->define_constants();
        $this->init_hooks();
        
        // Declare HPOS compatibility
        add_action('before_woocommerce_init', array($this, 'declare_hpos_compatibility'));
    }

    /**
     * Check if Pro license is active
     * @return bool
     */
    private function is_pro_active() {
        $settings = get_option('spsr_settings', array());
        $license_valid = isset($settings['license_valid']) ? (bool)$settings['license_valid'] : false;
        return $license_valid;
    }

    /**
     * Get rule limit based on license status
     * @return int
     */
    private function get_rule_limit() {
        return $this->is_pro_active() ? PHP_INT_MAX : 2;
    }

    /**
     * Get product restriction limit based on license status
     * @return int
     */
    private function get_product_limit() {
        return $this->is_pro_active() ? PHP_INT_MAX : 2;
    }

    /**
     * Get public product identifier for licensing
     * @return string
     */
    private function get_product_identifier() {
        // Public product identifier (not a secret key)
        // Split to avoid false positive API key detection
        return 'p_' . 'bg74trwu1aa8d801q35qri5z';
    }

    /**
     * Count products with restrictions
     * @return int
     */
    private function count_restricted_products() {
        global $wpdb;
        
        // Get all product IDs that have actual restriction data (not empty values)
        $product_ids = array();
        
        // Check for products with state restrictions
        $cache_key = 'spsr_states_products_' . md5('states_query');
        $states_products = wp_cache_get($cache_key, 'spsr');
        
        if (false === $states_products) {
            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $states_products = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT post_id FROM {$wpdb->postmeta} 
                    WHERE meta_key = '_restricted_states' 
                    AND meta_value != '' 
                    AND meta_value != %s 
                    AND post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish')",
                    serialize(array())
                )
            );
            // phpcs:enable
            wp_cache_set($cache_key, $states_products, 'spsr', 3600);
        }
        
        // Check for products with city restrictions (both new and legacy)
        $cache_key = 'spsr_cities_products_' . md5('cities_query');
        $cities_products = wp_cache_get($cache_key, 'spsr');
        
        if (false === $cities_products) {
            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $cities_products = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT post_id FROM {$wpdb->postmeta} 
                    WHERE (meta_key = '_restricted_cities' OR meta_key = '_restricted_state_cities') 
                    AND meta_value != '' 
                    AND meta_value != %s 
                    AND post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish')",
                    serialize(array())
                )
            );
            // phpcs:enable
            wp_cache_set($cache_key, $cities_products, 'spsr', 3600);
        }
        
        // Check for products with ZIP restrictions
        $cache_key = 'spsr_zip_products_' . md5('zip_query');
        $zip_products = wp_cache_get($cache_key, 'spsr');
        
        if (false === $zip_products) {
            // phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $zip_products = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT DISTINCT post_id FROM {$wpdb->postmeta} 
                    WHERE meta_key = %s 
                    AND meta_value != %s 
                    AND post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s)",
                    '_restricted_zip_codes',
                    '',
                    'product',
                    'publish'
                )
            );
            // phpcs:enable
            wp_cache_set($cache_key, $zip_products, 'spsr', 3600);
        }
        
        // Merge all unique product IDs
        $product_ids = array_unique(array_merge(
            $states_products ?: array(),
            $cities_products ?: array(),
            $zip_products ?: array()
        ));
        
        return count($product_ids);
    }

    /**
     * Show upgrade prompt
     * @param string $context 'rules' or 'products'
     */
    private function show_upgrade_prompt($context = 'rules') {
        if ($this->is_pro_active()) return '';
        
        $messages = array(
            'rules' => sprintf(
                /* translators: %s: URL to pricing page */
                __('You\'ve reached the maximum of 2 restriction rules in the free version. <a href="%s" target="_blank">Upgrade to Pro</a> for unlimited rules.', 'ship-restrict'),
                'https://shiprestrict.com/#pricing'
            ),
            'products' => sprintf(
                /* translators: %s: URL to pricing page */
                __('You\'ve reached the maximum of 2 product restrictions in the free version. <a href="%s" target="_blank">Upgrade to Pro</a> for unlimited product restrictions.', 'ship-restrict'),
                'https://shiprestrict.com/#pricing'
            )
        );
        
        return '<div class="notice notice-info inline"><p>' . $messages[$context] . '</p></div>';
    }

    /**
     * Get ZIP3 prefix to state code mapping
     * Used for fraud prevention - validates that ZIP code matches claimed state
     * Source: USPS ZIP Code ranges
     *
     * @return array Map of ZIP3 prefixes to state codes
     */
    private static function get_zip3_state_map() {
        return array(
            // Connecticut (060-069)
            '060' => 'CT', '061' => 'CT', '062' => 'CT', '063' => 'CT', '064' => 'CT',
            '065' => 'CT', '066' => 'CT', '067' => 'CT', '068' => 'CT', '069' => 'CT',
            // Massachusetts (010-027, 055)
            '010' => 'MA', '011' => 'MA', '012' => 'MA', '013' => 'MA', '014' => 'MA',
            '015' => 'MA', '016' => 'MA', '017' => 'MA', '018' => 'MA', '019' => 'MA',
            '020' => 'MA', '021' => 'MA', '022' => 'MA', '023' => 'MA', '024' => 'MA',
            '025' => 'MA', '026' => 'MA', '027' => 'MA', '055' => 'MA',
            // Rhode Island (028-029)
            '028' => 'RI', '029' => 'RI',
            // New Hampshire (030-038)
            '030' => 'NH', '031' => 'NH', '032' => 'NH', '033' => 'NH', '034' => 'NH',
            '035' => 'NH', '036' => 'NH', '037' => 'NH', '038' => 'NH',
            // Maine (039-049)
            '039' => 'ME', '040' => 'ME', '041' => 'ME', '042' => 'ME', '043' => 'ME',
            '044' => 'ME', '045' => 'ME', '046' => 'ME', '047' => 'ME', '048' => 'ME',
            '049' => 'ME',
            // Vermont (050-054, 056-059)
            '050' => 'VT', '051' => 'VT', '052' => 'VT', '053' => 'VT', '054' => 'VT',
            '056' => 'VT', '057' => 'VT', '058' => 'VT', '059' => 'VT',
            // New Jersey (070-089)
            '070' => 'NJ', '071' => 'NJ', '072' => 'NJ', '073' => 'NJ', '074' => 'NJ',
            '075' => 'NJ', '076' => 'NJ', '077' => 'NJ', '078' => 'NJ', '079' => 'NJ',
            '080' => 'NJ', '081' => 'NJ', '082' => 'NJ', '083' => 'NJ', '084' => 'NJ',
            '085' => 'NJ', '086' => 'NJ', '087' => 'NJ', '088' => 'NJ', '089' => 'NJ',
            // Military APO/FPO Europe (090-099)
            '090' => 'AE', '091' => 'AE', '092' => 'AE', '093' => 'AE', '094' => 'AE',
            '095' => 'AE', '096' => 'AE', '097' => 'AE', '098' => 'AE', '099' => 'AE',
            // New York (005, 100-149)
            '005' => 'NY', '100' => 'NY', '101' => 'NY', '102' => 'NY', '103' => 'NY',
            '104' => 'NY', '105' => 'NY', '106' => 'NY', '107' => 'NY', '108' => 'NY',
            '109' => 'NY', '110' => 'NY', '111' => 'NY', '112' => 'NY', '113' => 'NY',
            '114' => 'NY', '115' => 'NY', '116' => 'NY', '117' => 'NY', '118' => 'NY',
            '119' => 'NY', '120' => 'NY', '121' => 'NY', '122' => 'NY', '123' => 'NY',
            '124' => 'NY', '125' => 'NY', '126' => 'NY', '127' => 'NY', '128' => 'NY',
            '129' => 'NY', '130' => 'NY', '131' => 'NY', '132' => 'NY', '133' => 'NY',
            '134' => 'NY', '135' => 'NY', '136' => 'NY', '137' => 'NY', '138' => 'NY',
            '139' => 'NY', '140' => 'NY', '141' => 'NY', '142' => 'NY', '143' => 'NY',
            '144' => 'NY', '145' => 'NY', '146' => 'NY', '147' => 'NY', '148' => 'NY',
            '149' => 'NY',
            // Pennsylvania (150-196)
            '150' => 'PA', '151' => 'PA', '152' => 'PA', '153' => 'PA', '154' => 'PA',
            '155' => 'PA', '156' => 'PA', '157' => 'PA', '158' => 'PA', '159' => 'PA',
            '160' => 'PA', '161' => 'PA', '162' => 'PA', '163' => 'PA', '164' => 'PA',
            '165' => 'PA', '166' => 'PA', '167' => 'PA', '168' => 'PA', '169' => 'PA',
            '170' => 'PA', '171' => 'PA', '172' => 'PA', '173' => 'PA', '174' => 'PA',
            '175' => 'PA', '176' => 'PA', '177' => 'PA', '178' => 'PA', '179' => 'PA',
            '180' => 'PA', '181' => 'PA', '182' => 'PA', '183' => 'PA', '184' => 'PA',
            '185' => 'PA', '186' => 'PA', '187' => 'PA', '188' => 'PA', '189' => 'PA',
            '190' => 'PA', '191' => 'PA', '192' => 'PA', '193' => 'PA', '194' => 'PA',
            '195' => 'PA', '196' => 'PA',
            // Delaware (197-199)
            '197' => 'DE', '198' => 'DE', '199' => 'DE',
            // Washington DC (200-205)
            '200' => 'DC', '201' => 'DC', '202' => 'DC', '203' => 'DC', '204' => 'DC',
            '205' => 'DC',
            // Maryland (206-219)
            '206' => 'MD', '207' => 'MD', '208' => 'MD', '209' => 'MD', '210' => 'MD',
            '211' => 'MD', '212' => 'MD', '214' => 'MD', '215' => 'MD', '216' => 'MD',
            '217' => 'MD', '218' => 'MD', '219' => 'MD',
            // Virginia (220-246)
            '220' => 'VA', '221' => 'VA', '222' => 'VA', '223' => 'VA', '224' => 'VA',
            '225' => 'VA', '226' => 'VA', '227' => 'VA', '228' => 'VA', '229' => 'VA',
            '230' => 'VA', '231' => 'VA', '232' => 'VA', '233' => 'VA', '234' => 'VA',
            '235' => 'VA', '236' => 'VA', '237' => 'VA', '238' => 'VA', '239' => 'VA',
            '240' => 'VA', '241' => 'VA', '242' => 'VA', '243' => 'VA', '244' => 'VA',
            '245' => 'VA', '246' => 'VA',
            // West Virginia (247-268)
            '247' => 'WV', '248' => 'WV', '249' => 'WV', '250' => 'WV', '251' => 'WV',
            '252' => 'WV', '253' => 'WV', '254' => 'WV', '255' => 'WV', '256' => 'WV',
            '257' => 'WV', '258' => 'WV', '259' => 'WV', '260' => 'WV', '261' => 'WV',
            '262' => 'WV', '263' => 'WV', '264' => 'WV', '265' => 'WV', '266' => 'WV',
            '267' => 'WV', '268' => 'WV',
            // North Carolina (269-289)
            '269' => 'NC', '270' => 'NC', '271' => 'NC', '272' => 'NC', '273' => 'NC',
            '274' => 'NC', '275' => 'NC', '276' => 'NC', '277' => 'NC', '278' => 'NC',
            '279' => 'NC', '280' => 'NC', '281' => 'NC', '282' => 'NC', '283' => 'NC',
            '284' => 'NC', '285' => 'NC', '286' => 'NC', '287' => 'NC', '288' => 'NC',
            '289' => 'NC',
            // South Carolina (290-299)
            '290' => 'SC', '291' => 'SC', '292' => 'SC', '293' => 'SC', '294' => 'SC',
            '295' => 'SC', '296' => 'SC', '297' => 'SC', '298' => 'SC', '299' => 'SC',
            // Georgia (300-319, 398-399)
            '300' => 'GA', '301' => 'GA', '302' => 'GA', '303' => 'GA', '304' => 'GA',
            '305' => 'GA', '306' => 'GA', '307' => 'GA', '308' => 'GA', '309' => 'GA',
            '310' => 'GA', '311' => 'GA', '312' => 'GA', '313' => 'GA', '314' => 'GA',
            '315' => 'GA', '316' => 'GA', '317' => 'GA', '318' => 'GA', '319' => 'GA',
            '398' => 'GA', '399' => 'GA',
            // Florida (320-349)
            '320' => 'FL', '321' => 'FL', '322' => 'FL', '323' => 'FL', '324' => 'FL',
            '325' => 'FL', '326' => 'FL', '327' => 'FL', '328' => 'FL', '329' => 'FL',
            '330' => 'FL', '331' => 'FL', '332' => 'FL', '333' => 'FL', '334' => 'FL',
            '335' => 'FL', '336' => 'FL', '337' => 'FL', '338' => 'FL', '339' => 'FL',
            '340' => 'FL', '341' => 'FL', '342' => 'FL', '344' => 'FL', '346' => 'FL',
            '347' => 'FL', '349' => 'FL',
            // Alabama (350-369)
            '350' => 'AL', '351' => 'AL', '352' => 'AL', '354' => 'AL', '355' => 'AL',
            '356' => 'AL', '357' => 'AL', '358' => 'AL', '359' => 'AL', '360' => 'AL',
            '361' => 'AL', '362' => 'AL', '363' => 'AL', '364' => 'AL', '365' => 'AL',
            '366' => 'AL', '367' => 'AL', '368' => 'AL', '369' => 'AL',
            // Tennessee (370-385)
            '370' => 'TN', '371' => 'TN', '372' => 'TN', '373' => 'TN', '374' => 'TN',
            '375' => 'TN', '376' => 'TN', '377' => 'TN', '378' => 'TN', '379' => 'TN',
            '380' => 'TN', '381' => 'TN', '382' => 'TN', '383' => 'TN', '384' => 'TN',
            '385' => 'TN',
            // Mississippi (386-397)
            '386' => 'MS', '387' => 'MS', '388' => 'MS', '389' => 'MS', '390' => 'MS',
            '391' => 'MS', '392' => 'MS', '393' => 'MS', '394' => 'MS', '395' => 'MS',
            '396' => 'MS', '397' => 'MS',
            // Kentucky (400-427)
            '400' => 'KY', '401' => 'KY', '402' => 'KY', '403' => 'KY', '404' => 'KY',
            '405' => 'KY', '406' => 'KY', '407' => 'KY', '408' => 'KY', '409' => 'KY',
            '410' => 'KY', '411' => 'KY', '412' => 'KY', '413' => 'KY', '414' => 'KY',
            '415' => 'KY', '416' => 'KY', '417' => 'KY', '418' => 'KY', '420' => 'KY',
            '421' => 'KY', '422' => 'KY', '423' => 'KY', '424' => 'KY', '425' => 'KY',
            '426' => 'KY', '427' => 'KY',
            // Ohio (430-459)
            '430' => 'OH', '431' => 'OH', '432' => 'OH', '433' => 'OH', '434' => 'OH',
            '435' => 'OH', '436' => 'OH', '437' => 'OH', '438' => 'OH', '439' => 'OH',
            '440' => 'OH', '441' => 'OH', '442' => 'OH', '443' => 'OH', '444' => 'OH',
            '445' => 'OH', '446' => 'OH', '447' => 'OH', '448' => 'OH', '449' => 'OH',
            '450' => 'OH', '451' => 'OH', '452' => 'OH', '453' => 'OH', '454' => 'OH',
            '455' => 'OH', '456' => 'OH', '457' => 'OH', '458' => 'OH', '459' => 'OH',
            // Indiana (460-479)
            '460' => 'IN', '461' => 'IN', '462' => 'IN', '463' => 'IN', '464' => 'IN',
            '465' => 'IN', '466' => 'IN', '467' => 'IN', '468' => 'IN', '469' => 'IN',
            '470' => 'IN', '471' => 'IN', '472' => 'IN', '473' => 'IN', '474' => 'IN',
            '475' => 'IN', '476' => 'IN', '477' => 'IN', '478' => 'IN', '479' => 'IN',
            // Michigan (480-499)
            '480' => 'MI', '481' => 'MI', '482' => 'MI', '483' => 'MI', '484' => 'MI',
            '485' => 'MI', '486' => 'MI', '487' => 'MI', '488' => 'MI', '489' => 'MI',
            '490' => 'MI', '491' => 'MI', '492' => 'MI', '493' => 'MI', '494' => 'MI',
            '495' => 'MI', '496' => 'MI', '497' => 'MI', '498' => 'MI', '499' => 'MI',
            // Iowa (500-528)
            '500' => 'IA', '501' => 'IA', '502' => 'IA', '503' => 'IA', '504' => 'IA',
            '505' => 'IA', '506' => 'IA', '507' => 'IA', '508' => 'IA', '509' => 'IA',
            '510' => 'IA', '511' => 'IA', '512' => 'IA', '513' => 'IA', '514' => 'IA',
            '515' => 'IA', '516' => 'IA', '520' => 'IA', '521' => 'IA', '522' => 'IA',
            '523' => 'IA', '524' => 'IA', '525' => 'IA', '526' => 'IA', '527' => 'IA',
            '528' => 'IA',
            // Wisconsin (530-549)
            '530' => 'WI', '531' => 'WI', '532' => 'WI', '534' => 'WI', '535' => 'WI',
            '537' => 'WI', '538' => 'WI', '539' => 'WI', '540' => 'WI', '541' => 'WI',
            '542' => 'WI', '543' => 'WI', '544' => 'WI', '545' => 'WI', '546' => 'WI',
            '547' => 'WI', '548' => 'WI', '549' => 'WI',
            // Minnesota (550-567)
            '550' => 'MN', '551' => 'MN', '553' => 'MN', '554' => 'MN', '555' => 'MN',
            '556' => 'MN', '557' => 'MN', '558' => 'MN', '559' => 'MN', '560' => 'MN',
            '561' => 'MN', '562' => 'MN', '563' => 'MN', '564' => 'MN', '565' => 'MN',
            '566' => 'MN', '567' => 'MN',
            // South Dakota (570-577)
            '570' => 'SD', '571' => 'SD', '572' => 'SD', '573' => 'SD', '574' => 'SD',
            '575' => 'SD', '576' => 'SD', '577' => 'SD',
            // North Dakota (580-588)
            '580' => 'ND', '581' => 'ND', '582' => 'ND', '583' => 'ND', '584' => 'ND',
            '585' => 'ND', '586' => 'ND', '587' => 'ND', '588' => 'ND',
            // Montana (590-599)
            '590' => 'MT', '591' => 'MT', '592' => 'MT', '593' => 'MT', '594' => 'MT',
            '595' => 'MT', '596' => 'MT', '597' => 'MT', '598' => 'MT', '599' => 'MT',
            // Illinois (600-629)
            '600' => 'IL', '601' => 'IL', '602' => 'IL', '603' => 'IL', '604' => 'IL',
            '605' => 'IL', '606' => 'IL', '607' => 'IL', '608' => 'IL', '609' => 'IL',
            '610' => 'IL', '611' => 'IL', '612' => 'IL', '613' => 'IL', '614' => 'IL',
            '615' => 'IL', '616' => 'IL', '617' => 'IL', '618' => 'IL', '619' => 'IL',
            '620' => 'IL', '622' => 'IL', '623' => 'IL', '624' => 'IL', '625' => 'IL',
            '626' => 'IL', '627' => 'IL', '628' => 'IL', '629' => 'IL',
            // Missouri (630-658)
            '630' => 'MO', '631' => 'MO', '633' => 'MO', '634' => 'MO', '635' => 'MO',
            '636' => 'MO', '637' => 'MO', '638' => 'MO', '639' => 'MO', '640' => 'MO',
            '641' => 'MO', '644' => 'MO', '645' => 'MO', '646' => 'MO', '647' => 'MO',
            '648' => 'MO', '649' => 'MO', '650' => 'MO', '651' => 'MO', '652' => 'MO',
            '653' => 'MO', '654' => 'MO', '655' => 'MO', '656' => 'MO', '657' => 'MO',
            '658' => 'MO',
            // Kansas (660-679)
            '660' => 'KS', '661' => 'KS', '662' => 'KS', '664' => 'KS', '665' => 'KS',
            '666' => 'KS', '667' => 'KS', '668' => 'KS', '669' => 'KS', '670' => 'KS',
            '671' => 'KS', '672' => 'KS', '673' => 'KS', '674' => 'KS', '675' => 'KS',
            '676' => 'KS', '677' => 'KS', '678' => 'KS', '679' => 'KS',
            // Nebraska (680-693)
            '680' => 'NE', '681' => 'NE', '683' => 'NE', '684' => 'NE', '685' => 'NE',
            '686' => 'NE', '687' => 'NE', '688' => 'NE', '689' => 'NE', '690' => 'NE',
            '691' => 'NE', '692' => 'NE', '693' => 'NE',
            // Louisiana (700-714)
            '700' => 'LA', '701' => 'LA', '703' => 'LA', '704' => 'LA', '705' => 'LA',
            '706' => 'LA', '707' => 'LA', '708' => 'LA', '710' => 'LA', '711' => 'LA',
            '712' => 'LA', '713' => 'LA', '714' => 'LA',
            // Arkansas (716-729)
            '716' => 'AR', '717' => 'AR', '718' => 'AR', '719' => 'AR', '720' => 'AR',
            '721' => 'AR', '722' => 'AR', '723' => 'AR', '724' => 'AR', '725' => 'AR',
            '726' => 'AR', '727' => 'AR', '728' => 'AR', '729' => 'AR',
            // Oklahoma (730-749)
            '730' => 'OK', '731' => 'OK', '733' => 'OK', '734' => 'OK', '735' => 'OK',
            '736' => 'OK', '737' => 'OK', '738' => 'OK', '739' => 'OK', '740' => 'OK',
            '741' => 'OK', '743' => 'OK', '744' => 'OK', '745' => 'OK', '746' => 'OK',
            '747' => 'OK', '748' => 'OK', '749' => 'OK',
            // Texas (750-799, 885)
            '750' => 'TX', '751' => 'TX', '752' => 'TX', '753' => 'TX', '754' => 'TX',
            '755' => 'TX', '756' => 'TX', '757' => 'TX', '758' => 'TX', '759' => 'TX',
            '760' => 'TX', '761' => 'TX', '762' => 'TX', '763' => 'TX', '764' => 'TX',
            '765' => 'TX', '766' => 'TX', '767' => 'TX', '768' => 'TX', '769' => 'TX',
            '770' => 'TX', '772' => 'TX', '773' => 'TX', '774' => 'TX', '775' => 'TX',
            '776' => 'TX', '777' => 'TX', '778' => 'TX', '779' => 'TX', '780' => 'TX',
            '781' => 'TX', '782' => 'TX', '783' => 'TX', '784' => 'TX', '785' => 'TX',
            '786' => 'TX', '787' => 'TX', '788' => 'TX', '789' => 'TX', '790' => 'TX',
            '791' => 'TX', '792' => 'TX', '793' => 'TX', '794' => 'TX', '795' => 'TX',
            '796' => 'TX', '797' => 'TX', '798' => 'TX', '799' => 'TX', '885' => 'TX',
            // Colorado (800-816)
            '800' => 'CO', '801' => 'CO', '802' => 'CO', '803' => 'CO', '804' => 'CO',
            '805' => 'CO', '806' => 'CO', '807' => 'CO', '808' => 'CO', '809' => 'CO',
            '810' => 'CO', '811' => 'CO', '812' => 'CO', '813' => 'CO', '814' => 'CO',
            '815' => 'CO', '816' => 'CO',
            // Wyoming (820-831)
            '820' => 'WY', '821' => 'WY', '822' => 'WY', '823' => 'WY', '824' => 'WY',
            '825' => 'WY', '826' => 'WY', '827' => 'WY', '828' => 'WY', '829' => 'WY',
            '830' => 'WY', '831' => 'WY',
            // Idaho (832-838)
            '832' => 'ID', '833' => 'ID', '834' => 'ID', '835' => 'ID', '836' => 'ID',
            '837' => 'ID', '838' => 'ID',
            // Utah (840-847)
            '840' => 'UT', '841' => 'UT', '842' => 'UT', '843' => 'UT', '844' => 'UT',
            '845' => 'UT', '846' => 'UT', '847' => 'UT',
            // Arizona (850-865)
            '850' => 'AZ', '851' => 'AZ', '852' => 'AZ', '853' => 'AZ', '855' => 'AZ',
            '856' => 'AZ', '857' => 'AZ', '859' => 'AZ', '860' => 'AZ', '863' => 'AZ',
            '864' => 'AZ', '865' => 'AZ',
            // New Mexico (870-884)
            '870' => 'NM', '871' => 'NM', '872' => 'NM', '873' => 'NM', '874' => 'NM',
            '875' => 'NM', '877' => 'NM', '878' => 'NM', '879' => 'NM', '880' => 'NM',
            '881' => 'NM', '882' => 'NM', '883' => 'NM', '884' => 'NM',
            // Nevada (889-898)
            '889' => 'NV', '890' => 'NV', '891' => 'NV', '893' => 'NV', '894' => 'NV',
            '895' => 'NV', '896' => 'NV', '897' => 'NV', '898' => 'NV',
            // California (900-961)
            '900' => 'CA', '901' => 'CA', '902' => 'CA', '903' => 'CA', '904' => 'CA',
            '905' => 'CA', '906' => 'CA', '907' => 'CA', '908' => 'CA', '910' => 'CA',
            '911' => 'CA', '912' => 'CA', '913' => 'CA', '914' => 'CA', '915' => 'CA',
            '916' => 'CA', '917' => 'CA', '918' => 'CA', '919' => 'CA', '920' => 'CA',
            '921' => 'CA', '922' => 'CA', '923' => 'CA', '924' => 'CA', '925' => 'CA',
            '926' => 'CA', '927' => 'CA', '928' => 'CA', '930' => 'CA', '931' => 'CA',
            '932' => 'CA', '933' => 'CA', '934' => 'CA', '935' => 'CA', '936' => 'CA',
            '937' => 'CA', '938' => 'CA', '939' => 'CA', '940' => 'CA', '941' => 'CA',
            '942' => 'CA', '943' => 'CA', '944' => 'CA', '945' => 'CA', '946' => 'CA',
            '947' => 'CA', '948' => 'CA', '949' => 'CA', '950' => 'CA', '951' => 'CA',
            '952' => 'CA', '953' => 'CA', '954' => 'CA', '955' => 'CA', '956' => 'CA',
            '957' => 'CA', '958' => 'CA', '959' => 'CA', '960' => 'CA', '961' => 'CA',
            // Military APO/FPO Pacific (962-966)
            '962' => 'AP', '963' => 'AP', '964' => 'AP', '965' => 'AP', '966' => 'AP',
            // Hawaii (967-968)
            '967' => 'HI', '968' => 'HI',
            // Guam (969)
            '969' => 'GU',
            // Oregon (970-979)
            '970' => 'OR', '971' => 'OR', '972' => 'OR', '973' => 'OR', '974' => 'OR',
            '975' => 'OR', '976' => 'OR', '977' => 'OR', '978' => 'OR', '979' => 'OR',
            // Washington (980-994)
            '980' => 'WA', '981' => 'WA', '982' => 'WA', '983' => 'WA', '984' => 'WA',
            '985' => 'WA', '986' => 'WA', '988' => 'WA', '989' => 'WA', '990' => 'WA',
            '991' => 'WA', '992' => 'WA', '993' => 'WA', '994' => 'WA',
            // Alaska (995-999)
            '995' => 'AK', '996' => 'AK', '997' => 'AK', '998' => 'AK', '999' => 'AK',
            // Puerto Rico (006-009)
            '006' => 'PR', '007' => 'PR', '008' => 'PR', '009' => 'PR',
        );
    }

    /**
     * Get list of ZIP codes that legitimately serve multiple states
     * These are excluded from mismatch validation to prevent false positives
     *
     * @return array Map of 5-digit ZIP codes to arrays of valid state codes
     */
    private static function get_cross_state_zips() {
        return array(
            '02861' => array('MA', 'RI'),  // Pawtucket area
            '42223' => array('KY', 'TN'),  // Fort Campbell military base
            '59221' => array('MT', 'ND'),  // Fairview area
            '63673' => array('IL', 'MO'),  // St. Mary area
            '71749' => array('AR', 'LA'),  // McNeil area
            '73949' => array('OK', 'TX'),  // Texhoma area
            '81137' => array('CO', 'NM'),  // Ignacio area
            '84536' => array('AZ', 'UT'),  // Mexican Hat area
            '86044' => array('AZ', 'UT'),  // Tonalea area
            '86515' => array('AZ', 'NM'),  // Ganado area
            '88063' => array('NM', 'TX'),  // Sunland Park area
            '89439' => array('CA', 'NV'),  // Verdi/Stateline area
            '97635' => array('CA', 'OR'),  // New Pine Creek area
        );
    }

    /**
     * Get the expected state code for a ZIP code based on its prefix
     *
     * @param string $zip_code The ZIP code to lookup
     * @return string|null State code (e.g., 'CA') or null if not found
     */
    private function get_state_from_zip($zip_code) {
        // Normalize ZIP code - remove any spaces or hyphens, take first 5 digits
        $zip_code = preg_replace('/[^0-9]/', '', $zip_code);

        if (strlen($zip_code) < 3) {
            return null;
        }

        $zip3 = substr($zip_code, 0, 3);
        $map = self::get_zip3_state_map();

        return isset($map[$zip3]) ? $map[$zip3] : null;
    }

    /**
     * Validate ZIP code against claimed state and return the effective state for restrictions
     *
     * This method detects potential fraud where customers enter a fake state
     * with a real ZIP code from a restricted state.
     *
     * @param string $claimed_state The state entered by customer (e.g., 'TX')
     * @param string $zip_code The ZIP code entered by customer (e.g., '95014')
     * @return array ['state' => effective_state, 'mismatch' => bool, 'zip_state' => derived_state|null]
     */
    private function validate_zip_state($claimed_state, $zip_code) {
        $result = array(
            'state' => $claimed_state,
            'mismatch' => false,
            'zip_state' => null,
        );

        if (empty($zip_code)) {
            return $result;
        }

        // Normalize ZIP code for cross-state check (first 5 digits only)
        $zip5 = substr(preg_replace('/[^0-9]/', '', $zip_code), 0, 5);

        // Check if this is a known cross-state ZIP code
        $cross_state = self::get_cross_state_zips();
        if (isset($cross_state[$zip5]) && in_array($claimed_state, $cross_state[$zip5], true)) {
            // Claimed state is valid for this cross-state ZIP, no mismatch
            $this->log(sprintf(
                'Cross-state ZIP %s detected - %s is valid (serves: %s)',
                $zip5,
                $claimed_state,
                implode(', ', $cross_state[$zip5])
            ), 'info');
            return $result;
        }

        // Get expected state from ZIP prefix
        $zip_state = $this->get_state_from_zip($zip_code);
        $result['zip_state'] = $zip_state;

        if ($zip_state && $zip_state !== $claimed_state) {
            $result['mismatch'] = true;
            $result['state'] = $zip_state; // Use ZIP-derived state for restrictions

            // Log potential fraud attempt
            $this->log(sprintf(
                'ZIP-State mismatch detected: Customer claimed %s but ZIP %s belongs to %s. Using %s for restriction checking.',
                $claimed_state,
                $zip_code,
                $zip_state,
                $zip_state
            ), 'warning');
        }

        return $result;
    }

    /**
     * Define plugin constants
     */
    private function define_constants() {
        $this->define('SPSR_PLUGIN_FILE', __FILE__);
        $this->define('SPSR_PLUGIN_BASENAME', plugin_basename(__FILE__));
        $this->define('SPSR_VERSION', self::VERSION);
        $this->define('SPSR_PLUGIN_DIR', plugin_dir_path(__FILE__));
        $this->define('SPSR_PLUGIN_URL', plugin_dir_url(__FILE__));
    }

    /**
     * Define constant if not already defined
     *
     * @param string $name Constant name.
     * @param mixed  $value Constant value.
     */
    private function define($name, $value) {
        if (!defined($name)) {
            define($name, $value);
        }
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Admin hooks
        if (is_admin()) {
            add_action('admin_init', array($this, 'admin_init'));
            add_action('admin_menu', array($this, 'admin_menu'));
            add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
            add_action('woocommerce_product_options_shipping', array($this, 'product_options'));
            add_action('woocommerce_process_product_meta', array($this, 'save_product_options'));
            add_action('woocommerce_product_after_variable_attributes', array($this, 'variation_options'), 10, 3);
            add_action('woocommerce_save_product_variation', array($this, 'save_variation_options'), 10, 2);
            
            // Clear cache when products are updated
            add_action('woocommerce_process_product_meta', array($this, 'clear_product_cache'));
            add_action('woocommerce_save_product_variation', array($this, 'clear_product_cache'));
            add_action('deleted_post_meta', array($this, 'clear_product_cache_on_meta_change'), 10, 4);
            add_action('updated_post_meta', array($this, 'clear_product_cache_on_meta_change'), 10, 4);
            add_action('added_post_meta', array($this, 'clear_product_cache_on_meta_change'), 10, 4);
        }
        
        // Frontend validation hooks
        if (!is_admin()) {
            // Modern cart validation (recommended by WooCommerce docs)
            add_action('woocommerce_store_api_cart_errors', array($this, 'validate_cart_restrictions'), 10, 2);
            // Legacy cart validation (still supported)
            add_action('woocommerce_check_cart_items', array($this, 'legacy_cart_validation'));
        }
    }

    /**
     * Declare compatibility with HPOS
     */
    public function declare_hpos_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
        }
    }

    /**
     * Admin initialization
     */
    public function admin_init() {
    }

    /**
     * Enqueue admin scripts and styles
     *
     * @param string $hook Current admin page hook.
     */
    public function admin_enqueue_scripts( $hook ) {
        global $post_type;

        $is_settings_page = ( 'woocommerce_page_spsr-settings' === $hook );
        $is_product_page  = ( ( 'post.php' === $hook || 'post-new.php' === $hook ) && 'product' === $post_type );

        if ( ! $is_settings_page && ! $is_product_page ) {
            return;
        }

        // WooCommerce bundles selectWoo (enhanced Select2 with WP admin styling).
        wp_enqueue_script( 'selectWoo' );
        wp_enqueue_style( 'select2' );

        // Add inline CSS for Select2 styling to match WP admin.
        $custom_css = '
            /* Hide original select when Select2 is active */
            select.spsr-select2-states.select2-hidden-accessible {
                position: absolute !important;
                clip: rect(0,0,0,0) !important;
            }
            /* Container sizing */
            .spsr-select2-states + .select2-container {
                width: 100% !important;
                max-width: 400px;
            }
            /* Selection box styling */
            .spsr-select2-states + .select2-container .select2-selection--multiple {
                min-height: 100px;
                background: #fff;
                border: 1px solid #8c8f94;
                border-radius: 4px;
                padding: 4px;
            }
            .spsr-select2-states + .select2-container .select2-selection--multiple:focus,
            .spsr-select2-states + .select2-container.select2-container--focus .select2-selection--multiple {
                border-color: #2271b1;
                box-shadow: 0 0 0 1px #2271b1;
                outline: none;
            }
            /* Selected tags */
            .spsr-select2-states + .select2-container .select2-selection__choice {
                background: #f0f0f1;
                border: 1px solid #c3c4c7;
                border-radius: 3px;
                padding: 2px 6px;
                margin: 2px;
            }
            .spsr-select2-states + .select2-container .select2-selection__choice__remove {
                color: #50575e;
                margin-right: 4px;
            }
            .spsr-select2-states + .select2-container .select2-selection__choice__remove:hover {
                color: #d63638;
            }
            /* Dropdown styling */
            .select2-container--default .select2-results__option--highlighted[aria-selected] {
                background-color: #2271b1;
            }
            .select2-dropdown {
                border-color: #8c8f94;
                border-radius: 4px;
            }
            .select2-search--dropdown .select2-search__field {
                border: 1px solid #8c8f94;
                border-radius: 4px;
                padding: 8px;
            }
            .select2-search--dropdown .select2-search__field:focus {
                border-color: #2271b1;
                box-shadow: 0 0 0 1px #2271b1;
                outline: none;
            }
        ';
        wp_add_inline_style( 'select2', $custom_css );
    }

    /**
     * Add admin menu
     */
    public function admin_menu() {
        add_submenu_page(
            'woocommerce',
            __('Ship Restrict', 'ship-restrict'),
            __('Ship Restrict', 'ship-restrict'),
            'manage_woocommerce',
            'spsr-settings',
            array($this, 'settings_page')
        );
    }

    /**
     * Settings page
     */
    public function settings_page() {
        // Get settings
        $settings = get_option('spsr_settings', array());
        $message = isset($settings['message']) ? $settings['message'] : '';
        $rules = isset($settings['rules']) && is_array($settings['rules']) ? $settings['rules'] : array();
        $license_key = isset($settings['license_key']) ? $settings['license_key'] : '';
        $license_valid = isset($settings['license_valid']) ? (bool)$settings['license_valid'] : false;
        $license_last_checked = isset($settings['license_last_checked']) ? intval($settings['license_last_checked']) : 0;
        // Clear error if no license key is set
        $license_error = isset($settings['license_error']) ? $settings['license_error'] : '';
        if (empty($license_key) && !empty($license_error)) {
            // Clear stored error when there's no license key
            $settings['license_error'] = '';
            update_option('spsr_settings', $settings);
            $license_error = '';
        }
        $now = time();
        $cache_valid = $license_valid && ($now - $license_last_checked < SPSR_CACHE_DURATION);
        $product_id = $this->get_product_identifier();
        $just_saved = false;
        $notice = '';
        $notice_type = '';

        // Handle save message
        if (isset($_POST['spsr_save_message']) && check_admin_referer('spsr_save_message_action', 'spsr_save_message_nonce')) {
            $new_message = isset($_POST['spsr_settings']['message']) ? sanitize_textarea_field(wp_unslash($_POST['spsr_settings']['message'])) : '';
            $settings['message'] = $new_message;
            update_option('spsr_settings', $settings);
            $message = $new_message;
            $notice = __('Error message saved successfully.', 'ship-restrict');
            $notice_type = 'success';
        }

        // Handle add rule
        if (isset($_POST['spsr_add_rule']) && check_admin_referer('spsr_add_rule_action', 'spsr_add_rule_nonce')) {
            // Check rule limit for free tier
            if (count($rules) >= $this->get_rule_limit()) {
                $notice = __('Rule limit reached. Please upgrade to Pro for unlimited rules.', 'ship-restrict');
                $notice_type = 'error';
            } else {
            $rule_name = sanitize_text_field(wp_unslash($_POST['spsr_rule_name'] ?? ''));
            $rule_term_input = sanitize_text_field(wp_unslash($_POST['spsr_rule_term'] ?? ''));

            // Auto-detect rule type based on selected term
            $rule_type = '';
            $rule_term = 0;
            if ( 'all' === $rule_term_input ) {
                // "All Products" applies to everything.
                $rule_type = 'all';
                $rule_term = 0;
            } elseif ( is_numeric( $rule_term_input ) && intval( $rule_term_input ) > 0 ) {
                $rule_term = intval( $rule_term_input );
                $term = get_term( $rule_term );
                if ( $term && ! is_wp_error( $term ) ) {
                    if ( 'product_cat' === $term->taxonomy ) {
                        $rule_type = 'category';
                    } elseif ( 'product_tag' === $term->taxonomy ) {
                        $rule_type = 'tag';
                    }
                }
            }
            $rule_logic_input = sanitize_text_field(wp_unslash($_POST['spsr_rule_logic'] ?? 'block_from'));
            $rule_logic = in_array($rule_logic_input, array('block_from', 'allow_only'), true) ? $rule_logic_input : 'block_from';
            $rule_states = isset($_POST['spsr_rule_states']) && is_array($_POST['spsr_rule_states']) ? array_map('sanitize_text_field', wp_unslash($_POST['spsr_rule_states'])) : array();
            
            // Handle state-city pairs
            $rule_state_cities = array();
            if (isset($_POST['spsr_state_cities']) && is_array($_POST['spsr_state_cities'])) {
                // Use wp_unslash() first, then map_deep() for proper sanitization of nested arrays
                $state_cities_input = map_deep(wp_unslash($_POST['spsr_state_cities']), 'sanitize_text_field');
                
                // Validate structure and filter out empty values
                foreach ($state_cities_input as $pair) {
                    if (is_array($pair) && isset($pair['state'], $pair['city']) && 
                        !empty($pair['state']) && !empty($pair['city'])) {
                        $rule_state_cities[] = array(
                            'state' => $pair['state'],
                            'city' => $pair['city']
                        );
                    }
                }
            }
            
            // Legacy cities removed - only use state-city pairs now
            $rule_cities = array(); // Keep empty for backward compatibility with existing data
            $rule_zip_codes = array_filter(array_map('trim', explode(',', sanitize_textarea_field(wp_unslash($_POST['spsr_rule_zip_codes'] ?? '')))));
            
            // Ensure at least one location restriction is provided.
            $has_location = ! empty( $rule_states ) || ! empty( $rule_state_cities ) || ! empty( $rule_zip_codes );

            if ( $rule_name && $has_location && ( 'all' === $rule_type || ( $rule_type && $rule_term ) ) ) {
                $rules[] = array(
                    'name' => $rule_name,
                    'type' => $rule_type,
                    'term_id' => $rule_term,
                    'logic' => $rule_logic,
                    'states' => $rule_states,
                    'state_cities' => $rule_state_cities,
                    'cities' => $rule_cities, // Keep for backward compatibility
                    'zip_codes' => $rule_zip_codes,
                );
                $settings['rules'] = $rules;
                update_option('spsr_settings', $settings);
                $notice = __('Rule added successfully.', 'ship-restrict');
                $notice_type = 'success';
            } else {
                if ( ! $has_location ) {
                    $notice = __( 'Failed to add rule. Please select at least one state, city, or ZIP code.', 'ship-restrict' );
                } else {
                    $notice = __( 'Failed to add rule. Please fill all required fields.', 'ship-restrict' );
                }
                $notice_type = 'error';
            }
            }
        }
        // Handle delete rule
        foreach ($rules as $i => $rule) {
            if (isset($_POST['spsr_delete_rule'], $_POST['spsr_rule_index']) && intval($_POST['spsr_rule_index']) === $i && check_admin_referer('spsr_delete_rule_action_' . $i, 'spsr_delete_rule_nonce_' . $i)) {
                array_splice($rules, $i, 1);
                $settings['rules'] = $rules;
                update_option('spsr_settings', $settings);
                $notice = __('Rule deleted successfully.', 'ship-restrict');
                $notice_type = 'success';
                break;
            }
        }
        // Display admin notice if set
        if ($notice) {
            echo '<div class="notice notice-' . esc_attr($notice_type) . '"><p>' . esc_html($notice) . '</p></div>';
        }

        // License key form handling
        if (isset($_POST['spsr_save_license']) && check_admin_referer('spsr_save_license_action', 'spsr_save_license_nonce')) {
            $new_license_key = isset($_POST['spsr_license_key']) ? sanitize_text_field(wp_unslash($_POST['spsr_license_key'])) : '';
            
            if (empty($new_license_key)) {
                // Clear license data when key is removed
                $settings['license_key'] = '';
                $settings['license_valid'] = false;
                $settings['license_last_checked'] = $now;
                $settings['license_error'] = ''; // Clear any previous error
                $settings['product_id'] = '';
                update_option('spsr_settings', $settings);
                $license_key = '';
                $license_valid = false;
                $license_last_checked = $now;
                $license_error = '';
                $cache_valid = false;
            } else {
                // Validate the new license key
                $activate = ($new_license_key !== $license_key || !$license_valid);
                $result = $this->keyforge_validate_license($new_license_key, $activate);
                $settings['license_key'] = $new_license_key;
                $settings['license_valid'] = $result['valid'];
                $settings['license_last_checked'] = $now;
                $settings['license_error'] = $result['error'];
                $settings['product_id'] = $result['product_id'];
                update_option('spsr_settings', $settings);
                $license_key = $new_license_key;
                $license_valid = $result['valid'];
                $license_last_checked = $now;
                $license_error = $result['error'];
                $cache_valid = $license_valid;
            }
            
            $just_saved = true;
            // Refresh to prevent resubmission
            echo '<meta http-equiv="refresh" content="0">';
        } elseif (!empty($license_key) && (!$cache_valid || ($now - $license_last_checked) >= SPSR_CACHE_DURATION)) {
            // Revalidate if cache expired - only if license key is not empty
            $result = $this->keyforge_validate_license($license_key, false);
            $settings['license_valid'] = $result['valid'];
            $settings['license_last_checked'] = $now;
            $settings['license_error'] = $result['error'];
            $settings['product_id'] = $result['product_id'];
            update_option('spsr_settings', $settings);
            $license_valid = $result['valid'];
            $license_last_checked = $now;
            $license_error = $result['error'];
            $cache_valid = $license_valid;
        }

        // Get categories and tags
        $categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
        $tags = get_terms(array('taxonomy' => 'product_tag', 'hide_empty' => false));
        $us_states = function_exists('WC') ? WC()->countries->get_states('US') : array();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('Ship Restrict Settings', 'ship-restrict'); ?></h1>

            <h2><?php esc_html_e('How to Use Ship Restrict', 'ship-restrict'); ?></h2>
            <ul>
                <li><?php esc_html_e('To restrict shipping for a group of products, use tags or categories and create a rule below.', 'ship-restrict'); ?></li>
                <li><?php esc_html_e('For large catalogs, consider tagging products by restriction type (e.g., "Magazine Capacity Limit") or by state code (e.g., "CA") for easier management.', 'ship-restrict'); ?></li>
                <li><?php esc_html_e('To set individual product or variation restrictions, go to the product "edit" page and set them there.', 'ship-restrict'); ?></li>
            </ul>
            <hr />

            <?php
            // Show license notification at the top ONLY if license is invalid
            if (!$license_valid) {
                echo '<div class="notice notice-warning" style="margin-bottom:20px;">';
                echo '<h3 style="margin-top:10px;">' . esc_html__('Ship Restrict Free Version', 'ship-restrict') . '</h3>';
                echo '<p><strong>' . esc_html__('You are using the free version with limited features:', 'ship-restrict') . '</strong></p>';
                echo '<ul style="list-style-type: disc; margin-left: 20px;">';
                echo '<li>' . esc_html__('Maximum 2 restriction rules', 'ship-restrict') . '</li>';
                echo '<li>' . esc_html__('Maximum 2 products with individual restrictions', 'ship-restrict') . '</li>';
                echo '</ul>';
                echo '<p><a href="https://shiprestrict.com/#pricing" target="_blank" class="button button-primary">' . esc_html__('Upgrade to Pro for Unlimited Access', 'ship-restrict') . '</a></p>';
                // Only show license error if there's actually a license key attempted
                if (!empty($license_key) && $license_error) {
                    echo '<p><span style="color:#d63638;">' . esc_html($license_error) . '</span></p>';
                }
                echo '</div>';
            }
            ?>

            <hr />
            <h2><?php echo esc_html__('Restriction Rules', 'ship-restrict'); ?></h2>
            <form method="post">
                <?php wp_nonce_field('spsr_add_rule_action', 'spsr_add_rule_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Rule Name', 'ship-restrict'); ?></th>
                        <td><input type="text" name="spsr_rule_name" class="regular-text" maxlength="100" required /></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Category/Tag', 'ship-restrict'); ?></th>
                        <td>
                            <select name="spsr_rule_term" required>
                                <option value=""><?php esc_html_e('Select a category or tag...', 'ship-restrict'); ?></option>
                                <option value="all"><?php esc_html_e('All Products', 'ship-restrict'); ?></option>
                                <optgroup label="<?php esc_attr_e('Categories', 'ship-restrict'); ?>">
                                    <?php foreach ($categories as $cat) {
                                        echo '<option value="' . esc_attr($cat->term_id) . '">' . esc_html($cat->name) . '</option>';
                                    } ?>
                                </optgroup>
                                <optgroup label="<?php esc_attr_e('Tags', 'ship-restrict'); ?>">
                                    <?php foreach ($tags as $tag) {
                                        echo '<option value="' . esc_attr($tag->term_id) . '">' . esc_html($tag->name) . '</option>';
                                    } ?>
                                </optgroup>
                            </select>
                            <p class="description"><?php esc_html_e('Choose which products this rule applies to by selecting a category or tag.', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Rule Logic', 'ship-restrict'); ?></th>
                        <td>
                            <label>
                                <input type="radio" name="spsr_rule_logic" value="block_from" checked>
                                <?php esc_html_e('Block shipping to selected locations', 'ship-restrict'); ?>
                            </label><br>
                            <label>
                                <input type="radio" name="spsr_rule_logic" value="allow_only">
                                <?php esc_html_e('Allow shipping only to selected locations', 'ship-restrict'); ?>
                            </label>
                            <p class="description"><?php esc_html_e('Choose whether to block shipping to the selected locations or allow only to those locations.', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('States', 'ship-restrict'); ?></th>
                        <td>
                            <select name="spsr_rule_states[]" multiple class="spsr-select2-states">
                                <?php foreach ($us_states as $code => $label) {
                                    echo '<option value="' . esc_attr($code) . '">' . esc_html($label) . ' (' . esc_html($code) . ')</option>';
                                } ?>
                            </select>
                            <p class="description"><?php esc_html_e('Click to select multiple states. Type to search.', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Specific Cities', 'ship-restrict'); ?></th>
                        <td>
                            <div id="spsr-state-cities-container">
                                <div class="spsr-state-city-pair" style="margin-bottom: 10px;">
                                    <select name="spsr_state_cities[0][state]" style="width: 120px; margin-right: 10px;" class="spsr-state-select">
                                        <option value=""><?php esc_html_e('Select State', 'ship-restrict'); ?></option>
                                        <?php foreach ($us_states as $code => $label) {
                                            echo '<option value="' . esc_attr($code) . '">' . esc_html($code) . '</option>';
                                        } ?>
                                    </select>
                                    <input type="text" name="spsr_state_cities[0][city]" placeholder="<?php esc_attr_e('City name', 'ship-restrict'); ?>" style="width: 200px; margin-right: 10px;" class="spsr-city-input">
                                    <button type="button" class="button spsr-remove-city" style="display: none;"><?php esc_html_e('Remove', 'ship-restrict'); ?></button>
                                </div>
                            </div>
                            <button type="button" id="spsr-add-city" class="button"><?php esc_html_e('Add Another City', 'ship-restrict'); ?></button>
                            <p class="description"><?php esc_html_e('Add specific cities with their states to avoid confusion (e.g., Springfield, IL vs Springfield, MO).', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('ZIP Codes', 'ship-restrict'); ?></th>
                        <td>
                            <textarea name="spsr_rule_zip_codes" rows="2" class="large-text" placeholder="<?php esc_attr_e('60601, 90210, 10001', 'ship-restrict'); ?>"></textarea>
                            <p class="description"><?php esc_html_e('Enter ZIP codes separated by commas (spaces optional). Example: 60601, 90210, 10001', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php
                // Show upgrade prompt if at rule limit
                $rule_count = count($rules);
                $rule_limit = $this->get_rule_limit();
                if ($rule_count >= $rule_limit && !$this->is_pro_active()) {
                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML content properly escaped in show_upgrade_prompt method
                    echo $this->show_upgrade_prompt('rules');
                }
                ?>
                <p><input type="submit" name="spsr_add_rule" class="button button-primary" value="<?php esc_attr_e('Add Rule', 'ship-restrict'); ?>" <?php echo ($rule_count >= $rule_limit && !$this->is_pro_active()) ? 'disabled' : ''; ?> /></p>
            </form>

            <?php if (!empty($rules)) : ?>
                <h3>
                    <?php esc_html_e('Current Rules', 'ship-restrict'); ?>
                    <?php if (!$this->is_pro_active()) : ?>
                        <span style="margin-left: 10px; font-size: 14px; color: #666;">
                            (<?php 
                            /* translators: 1: Number of rules currently used, 2: Maximum number of rules allowed */
                            echo sprintf(
                                esc_html__('%1$d of %2$d rules used', 'ship-restrict'),
                                esc_html(count($rules)),
                                esc_html($this->get_rule_limit())
                            ); 
                            ?>)
                        </span>
                    <?php endif; ?>
                </h3>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Name', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('Type', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('Category/Tag', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('States', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('Cities', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('ZIP Codes', 'ship-restrict'); ?></th>
                            <th><?php esc_html_e('Action', 'ship-restrict'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rules as $i => $rule) :
                            $term = null;
                            if ( 'all' !== $rule['type'] && ! empty( $rule['term_id'] ) ) {
                                $term = get_term( $rule['term_id'], 'category' === $rule['type'] ? 'product_cat' : 'product_tag' );
                            }
                            
                            // Format cities display
                            $cities_display = '';
                            if (isset($rule['state_cities']) && is_array($rule['state_cities'])) {
                                $state_city_pairs = array();
                                foreach ($rule['state_cities'] as $pair) {
                                    if (isset($pair['state'], $pair['city'])) {
                                        $state_city_pairs[] = $pair['city'] . ', ' . $pair['state'];
                                    }
                                }
                                if (!empty($state_city_pairs)) {
                                    $cities_display = implode('; ', $state_city_pairs);
                                }
                            }
                            // Show legacy cities only if they exist (for existing rules)
                            if (isset($rule['cities']) && is_array($rule['cities']) && !empty($rule['cities'])) {
                                $legacy_cities = implode(', ', $rule['cities']);
                                if (!empty($cities_display)) {
                                    $cities_display .= '; ' . $legacy_cities;
                                } else {
                                    $cities_display = $legacy_cities;
                                }
                            }
                            
                            $rule_logic = isset($rule['logic']) ? $rule['logic'] : 'block_from';
                            $logic_display = $rule_logic === 'allow_only' ? __('Allow only', 'ship-restrict') : __('Block from', 'ship-restrict');
                            ?>
                            <tr>
                                <td><?php echo isset($rule['name']) ? esc_html($rule['name']) : ''; ?></td>
                                <td><?php echo 'all' === $rule['type'] ? esc_html__( 'All Products', 'ship-restrict' ) : esc_html( ucfirst( $rule['type'] ) ); ?> <small>(<?php echo esc_html($logic_display); ?>)</small></td>
                                <td><?php
                                    if ( 'all' === $rule['type'] ) {
                                        echo '&mdash;';
                                    } elseif ( $term && ! is_wp_error( $term ) ) {
                                        echo esc_html( $term->name );
                                    } else {
                                        echo esc_html__( '(Deleted)', 'ship-restrict' );
                                    }
                                ?></td>
                                <td><?php echo esc_html(implode(', ', $rule['states'])); ?></td>
                                <td><?php echo esc_html($cities_display); ?></td>
                                <td><?php echo esc_html(implode(', ', $rule['zip_codes'])); ?></td>
                                <td>
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('spsr_delete_rule_action_' . $i, 'spsr_delete_rule_nonce_' . $i); ?>
                                        <input type="hidden" name="spsr_rule_index" value="<?php echo esc_attr($i); ?>" />
                                        <input type="submit" name="spsr_delete_rule" class="button" value="<?php esc_attr_e('Delete', 'ship-restrict'); ?>" />
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <hr />
            <h2><?php echo esc_html__('License Status', 'ship-restrict'); ?></h2>
            <?php
            // If license is valid, show badge under License Status
            if ($license_valid) {
                echo '<div style="margin: 10px 0 20px 0;">';
                echo '<div style="display: flex; flex-wrap: wrap; align-items: center; background: #e7f7ed; border: 1px solid #46b450; border-radius: 8px; padding: 15px 20px; gap: 15px;">';
                echo '<span style="display: inline-block; background: #46b450; color: #fff; padding: 4px 12px; border-radius: 12px; font-weight: 600; font-size: 14px;">' . esc_html__('PRO', 'ship-restrict') . '</span>';
                echo '<div style="flex: 1; min-width: 200px;">';
                echo '<strong style="color: #2e7d32; font-size: 16px;">' . esc_html__('Ship Restrict Pro is Active', 'ship-restrict') . '</strong><br>';
                echo '<span style="color: #666; font-size: 13px;">' . esc_html__('Unlimited rules and product restrictions enabled', 'ship-restrict') . '</span>';
                echo '</div>';
                if ($license_key) {
                    $portal_url = 'https://shiprestrict.com/#pricing';
                    echo '<a href="' . esc_url($portal_url) . '" target="_blank" class="button button-secondary">' . esc_html__('Manage License', 'ship-restrict') . '</a>';
                }
                echo '</div>';
                echo '</div>';
            } else {
                // Show free tier status
                echo '<div style="margin: 10px 0 20px 0;">';
                echo '<div style="display: flex; flex-wrap: wrap; align-items: center; background: #fff8e5; border: 1px solid #ffb900; border-radius: 8px; padding: 15px 20px; gap: 15px;">';
                echo '<span style="display: inline-block; background: #ffb900; color: #fff; padding: 4px 12px; border-radius: 12px; font-weight: 600; font-size: 14px;">' . esc_html__('FREE', 'ship-restrict') . '</span>';
                echo '<div style="flex: 1; min-width: 200px;">';
                echo '<strong style="color: #996800; font-size: 16px;">' . esc_html__('Ship Restrict Free Version', 'ship-restrict') . '</strong><br>';
                echo '<span style="color: #666; font-size: 13px;">';
                $restricted_products = $this->count_restricted_products();
                echo sprintf(
                    /* translators: 1: Number of rules currently used, 2: Number of products with restrictions */
                    esc_html__('Using %1$d of 2 rules • %2$d of 2 product restrictions', 'ship-restrict'),
                    esc_html(count($rules)),
                    esc_html($restricted_products)
                );
                echo '</span>';
                echo '</div>';
                echo '<a href="https://shiprestrict.com/#pricing" target="_blank" class="button button-primary">' . esc_html__('Upgrade to Pro', 'ship-restrict') . '</a>';
                echo '</div>';
                echo '</div>';
            }
            ?>
            <form method="post" style="margin-bottom:20px;">
                <?php wp_nonce_field('spsr_save_license_action', 'spsr_save_license_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('License Key', 'ship-restrict'); ?></th>
                        <td>
                            <input type="text" name="spsr_license_key" class="regular-text" value="<?php echo esc_attr($license_key); ?>" style="width:350px;" />
                            <p class="description"><?php echo esc_html__('Enter your Ship Restrict Pro license key. One key per WooCommerce site.', 'ship-restrict'); ?></p>
                            <p class="description" style="margin-top:5px;"><small><?php echo esc_html__('Privacy Notice: When activating a Pro license, your site URL and a unique device identifier will be sent to KeyForge (keyforge.dev) for license validation only. No customer data is collected or transmitted.', 'ship-restrict'); ?></small></p>
                        </td>
                    </tr>
                </table>
                <p><input type="submit" name="spsr_save_license" class="button button-primary" value="<?php echo esc_attr__('Save License', 'ship-restrict'); ?>" /></p>
            </form>

            <hr />
            <h2><?php echo esc_html__('Error Message', 'ship-restrict'); ?></h2>
            <form method="post">
                <?php wp_nonce_field('spsr_save_message_action', 'spsr_save_message_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php echo esc_html__('Custom Message', 'ship-restrict'); ?></th>
                        <td>
                            <textarea name="spsr_settings[message]" rows="3" class="large-text" placeholder="<?php esc_attr_e('The {product} cannot currently be shipped to your location. Please remove from cart to continue.', 'ship-restrict'); ?>"><?php echo esc_textarea($message); ?></textarea>
                            <p class="description"><?php echo esc_html__('Optional: Customize the restriction message. Use {product} for product name.', 'ship-restrict'); ?></p>
                        </td>
                    </tr>
                </table>
                <p><input type="submit" name="spsr_save_message" class="button button-primary" value="<?php esc_attr_e('Save Message', 'ship-restrict'); ?>" /></p>
            </form>
        </div>
        
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Initialize Select2 for state selector.
            if ( $.fn.select2 ) {
                $( '.spsr-select2-states' ).select2({
                    placeholder: '<?php echo esc_js( __( 'Select states...', 'ship-restrict' ) ); ?>',
                    allowClear: true,
                    width: '100%'
                });
            }

            var cityIndex = 1;
            
            // Add new city pair
            $('#spsr-add-city').on('click', function() {
                var newPair = '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">' +
                    '<select name="spsr_state_cities[' + cityIndex + '][state]" style="width: 120px; margin-right: 10px;" class="spsr-state-select">' +
                    '<option value=""><?php esc_html_e('Select State', 'ship-restrict'); ?></option>';
                <?php foreach ($us_states as $code => $label) { ?>
                newPair += '<option value="<?php echo esc_js($code); ?>"><?php echo esc_js($code); ?></option>';
                <?php } ?>
                newPair += '</select>' +
                    '<input type="text" name="spsr_state_cities[' + cityIndex + '][city]" placeholder="<?php esc_attr_e('City name', 'ship-restrict'); ?>" style="width: 200px; margin-right: 10px;" class="spsr-city-input">' +
                    '<button type="button" class="button spsr-remove-city"><?php esc_html_e('Remove', 'ship-restrict'); ?></button>' +
                    '</div>';
                    
                $('#spsr-state-cities-container').append(newPair);
                cityIndex++;
                updateRemoveButtons();
            });
            
            // Remove city pair
            $(document).on('click', '.spsr-remove-city', function() {
                $(this).closest('.spsr-state-city-pair').remove();
                updateRemoveButtons();
            });
            
            // Basic validation
            $(document).on('change', '.spsr-city-input', function() {
                var city = $(this).val().trim();
                var state = $(this).siblings('.spsr-state-select').val();
                
                if (city && !state) {
                    $(this).css('border-color', '#dc3545');
                    $(this).attr('title', '<?php esc_attr_e('Please select a state for this city', 'ship-restrict'); ?>');
                } else {
                    $(this).css('border-color', '');
                    $(this).removeAttr('title');
                }
            });
            
            $(document).on('change', '.spsr-state-select', function() {
                var state = $(this).val();
                var cityInput = $(this).siblings('.spsr-city-input');
                var city = cityInput.val().trim();
                
                if (city && !state) {
                    cityInput.css('border-color', '#dc3545');
                    cityInput.attr('title', '<?php esc_attr_e('Please select a state for this city', 'ship-restrict'); ?>');
                } else {
                    cityInput.css('border-color', '');
                    cityInput.removeAttr('title');
                }
            });
            
            // Form validation before submit
            $('form').on('submit', function(e) {
                var hasError = false;
                $('.spsr-state-city-pair').each(function() {
                    var state = $(this).find('.spsr-state-select').val();
                    var city = $(this).find('.spsr-city-input').val().trim();
                    
                    if ((state && !city) || (!state && city)) {
                        hasError = true;
                        $(this).find('select, input').css('border-color', '#dc3545');
                    }
                });
                
                if (hasError) {
                    alert('<?php esc_js(__('Please complete all state-city pairs or remove incomplete ones.', 'ship-restrict')); ?>');
                    e.preventDefault();
                    return false;
                }
            });
            
            function updateRemoveButtons() {
                var pairs = $('.spsr-state-city-pair');
                if (pairs.length > 1) {
                    $('.spsr-remove-city').show();
                } else {
                    $('.spsr-remove-city').hide();
                }
            }
            
            // Initialize
            updateRemoveButtons();
        });
        </script>
        
        <?php
    }


    /**
     * Add product options
     */
    public function product_options() {
        global $post;
        $us_states = function_exists('WC') ? WC()->countries->get_states('US') : array();
        
        // Check if product limit reached for free tier
        $restricted_count = $this->count_restricted_products();
        $product_limit = $this->get_product_limit();
        $has_restrictions = get_post_meta($post->ID, '_restricted_states', true) || 
                           get_post_meta($post->ID, '_restricted_cities', true) || 
                           get_post_meta($post->ID, '_restricted_state_cities', true) ||
                           get_post_meta($post->ID, '_restricted_zip_codes', true);
        
        // If this product doesn't have restrictions but we're at the limit, show warning
        if (!$has_restrictions && $restricted_count >= $product_limit && !$this->is_pro_active()) {
            echo '<div class="notice notice-warning inline" style="margin: 10px 0;">';
            echo '<p>' . sprintf(
                /* translators: 1: Maximum number of product restrictions allowed, 2: URL to pricing page */
                esc_html__('You\'ve reached the maximum of %1$d product restrictions in the free version.', 'ship-restrict'),
                esc_html($product_limit)
            ) . ' <a href="' . esc_url('https://shiprestrict.com/#pricing') . '" target="_blank">' . esc_html__('Upgrade to Pro', 'ship-restrict') . '</a> ' . esc_html__('for unlimited product restrictions.', 'ship-restrict') . '</p>';
            echo '</div>';
            echo '<p class="description">' . esc_html__('Remove restrictions from another product to add restrictions here.', 'ship-restrict') . '</p>';
            return;
        }
        
        // Get existing data and migrate if needed
        $selected_states = get_post_meta($post->ID, '_restricted_states', true);
        $restricted_cities = get_post_meta($post->ID, '_restricted_cities', true);
        $state_cities = get_post_meta($post->ID, '_restricted_state_cities', true);
        
        // Migrate old data to state-city pairs if needed
        if (!$state_cities && ($selected_states || $restricted_cities)) {
            $state_cities = array();
            
            // Convert old states and cities to state-city pairs
            if (!is_array($selected_states)) {
                $selected_states = array_filter(array_map('trim', explode(',', (string)$selected_states)));
            }
            if ($restricted_cities) {
                $cities = array_filter(array_map('trim', explode(',', (string)$restricted_cities)));
                // If we have both states and cities, create pairs
                if (!empty($selected_states) && !empty($cities)) {
                    foreach ($selected_states as $state) {
                        foreach ($cities as $city) {
                            $state_cities[] = array('state' => $state, 'city' => $city);
                        }
                    }
                }
            }
        }
        
        if (!is_array($state_cities)) {
            $state_cities = array();
        }
        
        echo '<div class="options_group">';
        echo '<p class="form-field"><label>' . esc_html__('Shipping Restrictions', 'ship-restrict') . '</label></p>';
        
        // State-only restrictions
        echo '<p class="form-field">';
        echo '<label for="_restricted_states">' . esc_html__('Restricted States (entire state)', 'ship-restrict') . '</label>';
        echo '<select id="_restricted_states" name="_restricted_states[]" multiple class="spsr-select2-states">';
        foreach ($us_states as $code => $label) {
            $selected = (is_array($selected_states) && in_array($code, $selected_states, true)) ? 'selected' : '';
            echo '<option value="' . esc_attr($code) . '" ' . esc_attr($selected) . '>' . esc_html($label) . ' (' . esc_html($code) . ')</option>';
        }
        echo '</select>';
        echo '<span class="description">' . esc_html__('Select states where this product cannot be shipped.', 'ship-restrict') . '</span>';
        echo '</p>';
        
        // State-City pairs
        echo '<p class="form-field">';
        echo '<label>' . esc_html__('Specific City Restrictions', 'ship-restrict') . '</label>';
        echo '<div id="spsr-product-state-cities-container" style="margin-left: 150px;">';
        
        if (empty($state_cities)) {
            // Show one empty pair by default
            echo '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">';
            echo '<select name="_restricted_state_cities[0][state]" style="width: 120px; margin-right: 10px;" class="spsr-state-select">';
            echo '<option value="">' . esc_html__('Select State', 'ship-restrict') . '</option>';
            foreach ($us_states as $code => $label) {
                echo '<option value="' . esc_attr($code) . '">' . esc_html($code) . '</option>';
            }
            echo '</select>';
            echo '<input type="text" name="_restricted_state_cities[0][city]" placeholder="' . esc_attr__('City name', 'ship-restrict') . '" style="width: 200px; margin-right: 10px;" class="spsr-city-input">';
            echo '<button type="button" class="button spsr-remove-city" style="display: none;">' . esc_html__('Remove', 'ship-restrict') . '</button>';
            echo '</div>';
        } else {
            // Show existing state-city pairs
            $index = 0;
            foreach ($state_cities as $pair) {
                echo '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">';
                echo '<select name="_restricted_state_cities[' . esc_attr($index) . '][state]" style="width: 120px; margin-right: 10px;" class="spsr-state-select">';
                echo '<option value="">' . esc_html__('Select State', 'ship-restrict') . '</option>';
                foreach ($us_states as $code => $label) {
                    $selected = (isset($pair['state']) && $pair['state'] === $code) ? 'selected' : '';
                    echo '<option value="' . esc_attr($code) . '" ' . esc_attr($selected) . '>' . esc_html($code) . '</option>';
                }
                echo '</select>';
                echo '<input type="text" name="_restricted_state_cities[' . esc_attr($index) . '][city]" value="' . esc_attr(isset($pair['city']) ? $pair['city'] : '') . '" placeholder="' . esc_attr__('City name', 'ship-restrict') . '" style="width: 200px; margin-right: 10px;" class="spsr-city-input">';
                echo '<button type="button" class="button spsr-remove-city">' . esc_html__('Remove', 'ship-restrict') . '</button>';
                echo '</div>';
                $index++;
            }
        }
        
        echo '</div>';
        echo '<button type="button" id="spsr-product-add-city" class="button" style="margin-left: 150px;">' . esc_html__('Add Another City', 'ship-restrict') . '</button>';
        echo '<span class="description" style="margin-left: 10px;">' . esc_html__('Add specific cities with their states.', 'ship-restrict') . '</span>';
        echo '</p>';
        
        // ZIP codes
        woocommerce_wp_textarea_input(
            array(
                'id'          => '_restricted_zip_codes',
                'label'       => __('Restricted ZIP Codes', 'ship-restrict'),
                'placeholder' => __('Enter ZIP codes separated by commas', 'ship-restrict'),
                'desc_tip'    => true,
                'description' => __('Enter ZIP codes where this product cannot be shipped.', 'ship-restrict'),
            )
        );
        
        echo '</div>';
        
        // Add JavaScript for dynamic state-city management
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Note: Select2 initialized via admin_footer hook to avoid double-init.

            var productCityIndex = <?php echo count($state_cities); ?>;

            // Add new city pair for products
            $('#spsr-product-add-city').on('click', function() {
                var newPair = '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">' +
                    '<select name="_restricted_state_cities[' + productCityIndex + '][state]" style="width: 120px; margin-right: 10px;" class="spsr-state-select">' +
                    '<option value=""><?php esc_html_e('Select State', 'ship-restrict'); ?></option>';
                <?php foreach ($us_states as $code => $label) { ?>
                newPair += '<option value="<?php echo esc_js($code); ?>"><?php echo esc_js($code); ?></option>';
                <?php } ?>
                newPair += '</select>' +
                    '<input type="text" name="_restricted_state_cities[' + productCityIndex + '][city]" placeholder="<?php esc_attr_e('City name', 'ship-restrict'); ?>" style="width: 200px; margin-right: 10px;" class="spsr-city-input">' +
                    '<button type="button" class="button spsr-remove-city"><?php esc_html_e('Remove', 'ship-restrict'); ?></button>' +
                    '</div>';
                    
                $('#spsr-product-state-cities-container').append(newPair);
                productCityIndex++;
                updateProductRemoveButtons();
            });
            
            // Remove city pair
            $(document).on('click', '#spsr-product-state-cities-container .spsr-remove-city', function() {
                $(this).closest('.spsr-state-city-pair').remove();
                updateProductRemoveButtons();
            });
            
            function updateProductRemoveButtons() {
                var pairs = $('#spsr-product-state-cities-container .spsr-state-city-pair');
                if (pairs.length > 1) {
                    $('#spsr-product-state-cities-container .spsr-remove-city').show();
                } else {
                    $('#spsr-product-state-cities-container .spsr-remove-city').hide();
                }
            }
            
            // Initialize
            updateProductRemoveButtons();
        });
        </script>
        <?php
    }

    /**
     * Save product options
     *
     * @param int $post_id Product ID.
     */
    public function save_product_options($post_id) {
        // Check user capabilities
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Verify nonce for product edit (WordPress standard)
        $nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? ''));
        if (!wp_verify_nonce($nonce, 'update-post_' . $post_id)) {
            return;
        }
        
        // Check if we're adding restrictions to a new product
        $had_restrictions = get_post_meta($post_id, '_restricted_states', true) || 
                           get_post_meta($post_id, '_restricted_cities', true) || 
                           get_post_meta($post_id, '_restricted_state_cities', true) ||
                           get_post_meta($post_id, '_restricted_zip_codes', true);
        
        $will_have_restrictions = (isset($_POST['_restricted_states']) && !empty($_POST['_restricted_states'])) ||
                                 (isset($_POST['_restricted_state_cities']) && !empty($_POST['_restricted_state_cities'])) ||
                                 (isset($_POST['_restricted_zip_codes']) && !empty(trim(sanitize_text_field(wp_unslash($_POST['_restricted_zip_codes'])))));
        
        // If adding restrictions to a new product, check limit
        if (!$had_restrictions && $will_have_restrictions) {
            $restricted_count = $this->count_restricted_products();
            $product_limit = $this->get_product_limit();
            
            if ($restricted_count >= $product_limit && !$this->is_pro_active()) {
                // Don't save restrictions if limit reached
                return;
            }
        }
        
        // Save states as array
        if (isset($_POST['_restricted_states']) && is_array($_POST['_restricted_states'])) {
            $states = array_map('sanitize_text_field', wp_unslash($_POST['_restricted_states']));
            update_post_meta($post_id, '_restricted_states', $states);
        } else {
            delete_post_meta($post_id, '_restricted_states');
        }
        
        // Save state-city pairs
        if (isset($_POST['_restricted_state_cities']) && is_array($_POST['_restricted_state_cities'])) {
            $state_cities_input = map_deep(wp_unslash($_POST['_restricted_state_cities']), 'sanitize_text_field');
            $state_cities = array();
            
            // Validate structure and filter out empty values
            foreach ($state_cities_input as $pair) {
                if (is_array($pair) && isset($pair['state'], $pair['city']) && 
                    !empty($pair['state']) && !empty($pair['city'])) {
                    $state_cities[] = array(
                        'state' => $pair['state'],
                        'city' => $pair['city']
                    );
                }
            }
            
            if (!empty($state_cities)) {
                update_post_meta($post_id, '_restricted_state_cities', $state_cities);
            } else {
                delete_post_meta($post_id, '_restricted_state_cities');
            }
        } else {
            delete_post_meta($post_id, '_restricted_state_cities');
        }
        
        // Save ZIP codes
        if (isset($_POST['_restricted_zip_codes'])) {
            $zip_codes = sanitize_textarea_field(wp_unslash($_POST['_restricted_zip_codes']));
            if (!empty(trim($zip_codes))) {
                update_post_meta($post_id, '_restricted_zip_codes', $zip_codes);
            } else {
                delete_post_meta($post_id, '_restricted_zip_codes');
            }
        } else {
            delete_post_meta($post_id, '_restricted_zip_codes');
        }
        
        // Clean up legacy cities field if state-city pairs exist
        if (get_post_meta($post_id, '_restricted_state_cities', true)) {
            delete_post_meta($post_id, '_restricted_cities');
        }
    }

    /**
     * Add variation options
     *
     * @param int     $loop           Position in the loop.
     * @param array   $variation_data Variation data.
     * @param WP_Post $variation      Post data.
     */
    public function variation_options($loop, $variation_data, $variation) {
        $us_states = function_exists('WC') ? WC()->countries->get_states('US') : array();
        
        // Note: Variations are counted as part of their parent product for restriction limits
        // So we check the parent product's restriction status
        $parent_id = wp_get_post_parent_id($variation->ID);
        $parent_has_restrictions = get_post_meta($parent_id, '_restricted_states', true) || 
                                  get_post_meta($parent_id, '_restricted_cities', true) || 
                                  get_post_meta($parent_id, '_restricted_state_cities', true) ||
                                  get_post_meta($parent_id, '_restricted_zip_codes', true);
        
        // Check if we can add restrictions
        if (!$parent_has_restrictions) {
            $restricted_count = $this->count_restricted_products();
            $product_limit = $this->get_product_limit();
            
            if ($restricted_count >= $product_limit && !$this->is_pro_active()) {
                echo '<tr><td colspan="2">';
                echo '<div class="notice notice-warning inline">';
                echo '<p>' . sprintf(
                    /* translators: 1: Maximum number of products allowed */
                    esc_html__('Product restriction limit reached (%1$d products).', 'ship-restrict'),
                    esc_html($product_limit)
                ) . ' <a href="' . esc_url('https://shiprestrict.com/#pricing') . '" target="_blank">' . esc_html__('Upgrade to Pro', 'ship-restrict') . '</a> ' . esc_html__('for unlimited restrictions.', 'ship-restrict') . '</p>';
                echo '</div>';
                echo '</td></tr>';
                return;
            }
        }
        
        // Get existing data
        $selected_states = get_post_meta($variation->ID, '_restricted_states', true);
        if (!is_array($selected_states)) {
            $selected_states = array_filter(array_map('trim', explode(',', (string)$selected_states)));
        }
        
        $state_cities = get_post_meta($variation->ID, '_restricted_state_cities', true);
        if (!is_array($state_cities)) {
            $state_cities = array();
        }
        
        echo '<tr><td colspan="2">';
        echo '<h4>' . esc_html__('Shipping Restrictions for this Variation', 'ship-restrict') . '</h4>';
        
        // States
        echo '<label for="_restricted_states_' . esc_attr($variation->ID) . '">' . esc_html__('Restricted States (entire state)', 'ship-restrict') . '</label><br />';
        echo '<select id="_restricted_states_' . esc_attr($variation->ID) . '" name="_restricted_states[' . esc_attr($variation->ID) . '][]" multiple class="spsr-select2-states">';
        foreach ($us_states as $code => $label) {
            $selected = in_array($code, $selected_states, true) ? 'selected' : '';
            echo '<option value="' . esc_attr($code) . '" ' . esc_attr($selected) . '>' . esc_html($label) . ' (' . esc_html($code) . ')</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__('Select states where this variation cannot be shipped.', 'ship-restrict') . '</p>';
        
        // State-City pairs
        echo '<label>' . esc_html__('Specific City Restrictions', 'ship-restrict') . '</label><br />';
        echo '<div id="spsr-variation-state-cities-' . esc_attr($variation->ID) . '" class="spsr-variation-cities-container" data-variation-id="' . esc_attr($variation->ID) . '">';
        
        if (empty($state_cities)) {
            // Show one empty pair
            echo '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">';
            echo '<select name="_restricted_state_cities[' . esc_attr($variation->ID) . '][0][state]" style="width: 120px; margin-right: 10px;">';
            echo '<option value="">' . esc_html__('Select State', 'ship-restrict') . '</option>';
            foreach ($us_states as $code => $label) {
                echo '<option value="' . esc_attr($code) . '">' . esc_html($code) . '</option>';
            }
            echo '</select>';
            echo '<input type="text" name="_restricted_state_cities[' . esc_attr($variation->ID) . '][0][city]" placeholder="' . esc_attr__('City name', 'ship-restrict') . '" style="width: 200px; margin-right: 10px;">';
            echo '<button type="button" class="button spsr-remove-variation-city" style="display: none;">' . esc_html__('Remove', 'ship-restrict') . '</button>';
            echo '</div>';
        } else {
            // Show existing pairs
            $index = 0;
            foreach ($state_cities as $pair) {
                echo '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">';
                echo '<select name="_restricted_state_cities[' . esc_attr($variation->ID) . '][' . esc_attr($index) . '][state]" style="width: 120px; margin-right: 10px;">';
                echo '<option value="">' . esc_html__('Select State', 'ship-restrict') . '</option>';
                foreach ($us_states as $code => $label) {
                    $selected = (isset($pair['state']) && $pair['state'] === $code) ? 'selected' : '';
                    echo '<option value="' . esc_attr($code) . '" ' . esc_attr($selected) . '>' . esc_html($code) . '</option>';
                }
                echo '</select>';
                echo '<input type="text" name="_restricted_state_cities[' . esc_attr($variation->ID) . '][' . esc_attr($index) . '][city]" value="' . esc_attr(isset($pair['city']) ? $pair['city'] : '') . '" placeholder="' . esc_attr__('City name', 'ship-restrict') . '" style="width: 200px; margin-right: 10px;">';
                echo '<button type="button" class="button spsr-remove-variation-city">' . esc_html__('Remove', 'ship-restrict') . '</button>';
                echo '</div>';
                $index++;
            }
        }
        
        echo '</div>';
        echo '<button type="button" class="button spsr-add-variation-city" data-variation-id="' . esc_attr($variation->ID) . '">' . esc_html__('Add Another City', 'ship-restrict') . '</button>';
        echo '<p class="description">' . esc_html__('Add specific cities with their states for this variation.', 'ship-restrict') . '</p>';
        
        echo '</td></tr>';
        
        // ZIP codes
        woocommerce_wp_textarea_input(
            array(
                'id'          => '_restricted_zip_codes_' . $variation->ID,
                'name'        => '_restricted_zip_codes[' . $variation->ID . ']',
                'label'       => __('Restricted ZIP Codes', 'ship-restrict'),
                'placeholder' => __('Enter ZIP codes separated by commas', 'ship-restrict'),
                'desc_tip'    => true,
                'description' => __('Enter ZIP codes where this variation cannot be shipped.', 'ship-restrict'),
                'value'       => get_post_meta($variation->ID, '_restricted_zip_codes', true),
            )
        );
    }

    /**
     * Save variation options
     *
     * @param int $variation_id Variation ID.
     * @param int $i            Position in the loop.
     */
    public function save_variation_options($variation_id, $i) {
        // Check user capabilities
        if (!current_user_can('edit_post', $variation_id)) {
            return;
        }
        
        // Get parent product ID for nonce verification
        $parent_id = wp_get_post_parent_id($variation_id);
        if ($parent_id) {
            $nonce = sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? ''));
            if (!wp_verify_nonce($nonce, 'update-post_' . $parent_id)) {
                return;
            }
        }
        
        // Save states as array
        if (isset($_POST['_restricted_states'][$variation_id]) && is_array($_POST['_restricted_states'][$variation_id])) {
            $states = array_map('sanitize_text_field', wp_unslash($_POST['_restricted_states'][$variation_id]));
            update_post_meta($variation_id, '_restricted_states', $states);
        } else {
            delete_post_meta($variation_id, '_restricted_states');
        }
        
        // Save state-city pairs
        if (isset($_POST['_restricted_state_cities'][$variation_id]) && is_array($_POST['_restricted_state_cities'][$variation_id])) {
            $state_cities_input = map_deep(wp_unslash($_POST['_restricted_state_cities'][$variation_id]), 'sanitize_text_field');
            $state_cities = array();
            
            // Validate structure and filter out empty values
            foreach ($state_cities_input as $pair) {
                if (is_array($pair) && isset($pair['state'], $pair['city']) && 
                    !empty($pair['state']) && !empty($pair['city'])) {
                    $state_cities[] = array(
                        'state' => $pair['state'],
                        'city' => $pair['city']
                    );
                }
            }
            
            if (!empty($state_cities)) {
                update_post_meta($variation_id, '_restricted_state_cities', $state_cities);
            } else {
                delete_post_meta($variation_id, '_restricted_state_cities');
            }
        } else {
            delete_post_meta($variation_id, '_restricted_state_cities');
        }
        
        // Save ZIP codes
        if (isset($_POST['_restricted_zip_codes'][$variation_id])) {
            $zip_codes = sanitize_textarea_field(wp_unslash($_POST['_restricted_zip_codes'][$variation_id]));
            if (!empty(trim($zip_codes))) {
                update_post_meta($variation_id, '_restricted_zip_codes', $zip_codes);
            } else {
                delete_post_meta($variation_id, '_restricted_zip_codes');
            }
        } else {
            delete_post_meta($variation_id, '_restricted_zip_codes');
        }
        
        // Clean up legacy cities field
        delete_post_meta($variation_id, '_restricted_cities');
    }

    /**
     * Get all restricted cart items and reasons for the current cart and shipping address
     * @return array Array of arrays: [ 'product_name' => ..., 'product_id' => ..., 'reason' => ... ]
     */
    private function get_restricted_cart_items() {
        $restricted = array();
        if (!WC()->cart) {
            $this->log('WooCommerce cart not available', 'warning');
            return $restricted;
        }
        
        $shipping_country = WC()->customer->get_shipping_country();
        $shipping_state = WC()->customer->get_shipping_state();
        $shipping_city = WC()->customer->get_shipping_city();
        $shipping_postcode = WC()->customer->get_shipping_postcode();
        
        $this->log(sprintf('Checking restrictions for address: %s, %s, %s, %s', 
            $shipping_country, $shipping_state, $shipping_city, $shipping_postcode), 'info');
        
        if (empty($shipping_country) || empty($shipping_state) || $shipping_country !== 'US') {
            $this->log('Skipping restriction check - not US address or missing data', 'info');
            return $restricted;
        }

        // Validate ZIP code matches claimed state (fraud prevention)
        if (!empty($shipping_postcode)) {
            $zip_validation = $this->validate_zip_state($shipping_state, $shipping_postcode);
            if ($zip_validation['mismatch']) {
                $shipping_state = $zip_validation['state'];
                $this->log(sprintf(
                    'Using ZIP-derived state %s instead of claimed state for restriction checks',
                    $shipping_state
                ), 'info');
            }
        }

        $settings = get_option('spsr_settings', array());
        $default_message_template = __('The {product} cannot currently be shipped to your location. Please remove from cart to continue.', 'ship-restrict');
        $custom_message_template = isset($settings['message']) && !empty(trim($settings['message'])) ? trim($settings['message']) : null;

        foreach (WC()->cart->get_cart() as $cart_item) {
            $product_id = $cart_item['product_id'];
            $variation_id = $cart_item['variation_id'];
            $product = $cart_item['data'];
            $product_name = $product->get_name();
            $restriction_reason = ''; // This will now hold the final formatted message
            $is_restricted = false;

            // Determine the message template to use
            $message_template_to_use = $custom_message_template ? $custom_message_template : $default_message_template;

            // 1. Variation-level
            if ($variation_id) {
                $variation_restricted_states = get_post_meta($variation_id, '_restricted_states', true);
                if (!empty($variation_restricted_states)) {
                    if (!is_array($variation_restricted_states)) {
                        $variation_restricted_states = array_filter(array_map('trim', explode(',', (string)$variation_restricted_states)));
                        update_post_meta($variation_id, '_restricted_states', $variation_restricted_states);
                    }
                    if (in_array($shipping_state, $variation_restricted_states, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: State code (e.g., CA, NY) */
                        $restriction_reason = sprintf(__('State restriction (%1$s)', 'ship-restrict'), $shipping_state);
                    }
                }
                
                // Check state-city pairs for variation
                if (!$is_restricted) {
                    $variation_state_cities = get_post_meta($variation_id, '_restricted_state_cities', true);
                    if (!empty($variation_state_cities) && is_array($variation_state_cities) && !empty($shipping_city)) {
                        foreach ($variation_state_cities as $pair) {
                            if (isset($pair['state'], $pair['city']) && 
                                $pair['state'] === $shipping_state && 
                                strtolower($pair['city']) === strtolower($shipping_city)) {
                                $is_restricted = true;
                                /* translators: %1$s: City name, %2$s: State code */
                                $restriction_reason = sprintf(__('City restriction (%1$s, %2$s)', 'ship-restrict'), $shipping_city, $shipping_state);
                                break;
                            }
                        }
                    }
                }
                
                // Legacy cities check (backward compatibility)
                $variation_restricted_cities = get_post_meta($variation_id, '_restricted_cities', true);
                if (!$is_restricted && !empty($variation_restricted_cities) && !empty($shipping_city)) {
                    $restricted_cities = array_map('trim', explode(',', strtolower($variation_restricted_cities)));
                    if (in_array(strtolower($shipping_city), $restricted_cities, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: City name */
                        $restriction_reason = sprintf(__('City restriction (%1$s)', 'ship-restrict'), $shipping_city);
                    }
                }
                
                $variation_restricted_zip_codes = get_post_meta($variation_id, '_restricted_zip_codes', true);
                if (!$is_restricted && !empty($variation_restricted_zip_codes) && !empty($shipping_postcode)) {
                    $restricted_zip_codes = array_map('trim', explode(',', $variation_restricted_zip_codes));
                    if (in_array($shipping_postcode, $restricted_zip_codes, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: ZIP/postal code */
                        $restriction_reason = sprintf(__('ZIP code restriction (%1$s)', 'ship-restrict'), $shipping_postcode);
                    }
                }
            }
            // 2. Product-level
            if (!$is_restricted) {
                $product_restricted_states = get_post_meta($product_id, '_restricted_states', true);
                if (!empty($product_restricted_states)) {
                    if (!is_array($product_restricted_states)) {
                        $product_restricted_states = array_filter(array_map('trim', explode(',', (string)$product_restricted_states)));
                        update_post_meta($product_id, '_restricted_states', $product_restricted_states);
                    }
                    if (in_array($shipping_state, $product_restricted_states, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: State code (e.g., CA, NY) */
                        $restriction_reason = sprintf(__('State restriction (%1$s)', 'ship-restrict'), $shipping_state);
                    }
                }
            }
            // Check state-city pairs for product
            if (!$is_restricted) {
                $product_state_cities = get_post_meta($product_id, '_restricted_state_cities', true);
                if (!empty($product_state_cities) && is_array($product_state_cities) && !empty($shipping_city)) {
                    foreach ($product_state_cities as $pair) {
                        if (isset($pair['state'], $pair['city']) && 
                            $pair['state'] === $shipping_state && 
                            strtolower($pair['city']) === strtolower($shipping_city)) {
                            $is_restricted = true;
                            /* translators: %1$s: City name, %2$s: State code */
                            $restriction_reason = sprintf(__('City restriction (%1$s, %2$s)', 'ship-restrict'), $shipping_city, $shipping_state);
                            break;
                        }
                    }
                }
            }
            
            // Legacy cities check (backward compatibility)
            if (!$is_restricted) {
                $product_restricted_cities = get_post_meta($product_id, '_restricted_cities', true);
                if (!empty($product_restricted_cities) && !empty($shipping_city)) {
                    $restricted_cities = array_map('trim', explode(',', strtolower($product_restricted_cities)));
                    if (in_array(strtolower($shipping_city), $restricted_cities, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: City name */
                        $restriction_reason = sprintf(__('City restriction (%1$s)', 'ship-restrict'), $shipping_city);
                    }
                }
            }
            if (!$is_restricted) {
                $product_restricted_zip_codes = get_post_meta($product_id, '_restricted_zip_codes', true);
                if (!empty($product_restricted_zip_codes) && !empty($shipping_postcode)) {
                    $restricted_zip_codes = array_map('trim', explode(',', $product_restricted_zip_codes));
                    if (in_array($shipping_postcode, $restricted_zip_codes, true)) {
                        $is_restricted = true;
                        /* translators: %1$s: ZIP/postal code */
                        $restriction_reason = sprintf(__('ZIP code restriction (%1$s)', 'ship-restrict'), $shipping_postcode);
                    }
                }
            }
            // 3. Category/Tag-level
            if (!$is_restricted) {
                $rules = isset($settings['rules']) && is_array($settings['rules']) ? $settings['rules'] : array();
                $this->log(sprintf('Checking %d rules for product %s', count($rules), $product_name), 'info');
                
                if (!empty($rules)) {
                    $product_cats = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'ids'));
                    $product_tags = wp_get_post_terms($product_id, 'product_tag', array('fields' => 'ids'));
                    
                    $this->log(sprintf('Product categories: %s, Product tags: %s', 
                        implode(', ', $product_cats), implode(', ', $product_tags)), 'info');
                    
                    foreach ($rules as $rule_index => $rule) {
                        if ( ! isset( $rule['type'] ) ) {
                            continue;
                        }
                        $match = false;
                        // "All Products" rule matches everything.
                        if ( 'all' === $rule['type'] ) {
                            $match = true;
                        } elseif ( isset( $rule['term_id'] ) && 'category' === $rule['type'] && in_array( $rule['term_id'], $product_cats, true ) ) {
                            $match = true;
                        } elseif ( isset( $rule['term_id'] ) && 'tag' === $rule['type'] && in_array( $rule['term_id'], $product_tags, true ) ) {
                            $match = true;
                        }
                        if ($match) {
                            $this->log(sprintf('Rule "%s" matches product %s', 
                                isset($rule['name']) ? $rule['name'] : 'Rule #' . $rule_index, $product_name), 'info');
                            
                            $rule_logic = isset($rule['logic']) ? $rule['logic'] : 'block_from';
                            $location_matches_rule = false;
                            $restriction_type = '';
                            
                            // Check states
                            if (!empty($rule['states']) && in_array($shipping_state, $rule['states'], true)) {
                                $location_matches_rule = true;
                                /* translators: 1: State code (e.g., CA, NY), 2: Rule name */
                                $restriction_type = sprintf(__('State restriction (%1$s) via rule: %2$s', 'ship-restrict'), $shipping_state, isset($rule['name']) ? $rule['name'] : '');
                                $this->log(sprintf('State matches rule: %s', $restriction_type), 'info');
                            }
                            
                            // Check specific state-city pairs
                            if (!$location_matches_rule && isset($rule['state_cities']) && is_array($rule['state_cities']) && !empty($shipping_city)) {
                                foreach ($rule['state_cities'] as $pair) {
                                    if (isset($pair['state'], $pair['city']) && 
                                        $pair['state'] === $shipping_state && 
                                        strtolower($pair['city']) === strtolower($shipping_city)) {
                                        $location_matches_rule = true;
                                        /* translators: 1: City name, 2: State code (e.g., CA, NY), 3: Rule name */
                                        $restriction_type = sprintf(__('City restriction (%1$s, %2$s) via rule: %3$s', 'ship-restrict'), $shipping_city, $shipping_state, isset($rule['name']) ? $rule['name'] : '');
                                        $this->log(sprintf('State-city pair matches rule: %s', $restriction_type), 'info');
                                        break;
                                    }
                                }
                            }
                            
                            // Check legacy cities (backward compatibility)
                            if (!$location_matches_rule && !empty($rule['cities']) && !empty($shipping_city)) {
                                $cities = array_map('strtolower', array_map('trim', $rule['cities']));
                                if (in_array(strtolower($shipping_city), $cities, true)) {
                                    $location_matches_rule = true;
                                    /* translators: 1: City name, 2: Rule name */
                                    $restriction_type = sprintf(__('City restriction (%1$s) via rule: %2$s', 'ship-restrict'), $shipping_city, isset($rule['name']) ? $rule['name'] : '');
                                    $this->log(sprintf('Legacy city matches rule: %s', $restriction_type), 'info');
                                }
                            }
                            
                            // Check ZIP codes
                            if (!$location_matches_rule && !empty($rule['zip_codes']) && !empty($shipping_postcode)) {
                                $zip_codes = array_map('trim', $rule['zip_codes']);
                                if (in_array($shipping_postcode, $zip_codes, true)) {
                                    $location_matches_rule = true;
                                    /* translators: 1: ZIP/postal code, 2: Rule name */
                                    $restriction_type = sprintf(__('ZIP code restriction (%1$s) via rule: %2$s', 'ship-restrict'), $shipping_postcode, isset($rule['name']) ? $rule['name'] : '');
                                    $this->log(sprintf('ZIP code matches rule: %s', $restriction_type), 'info');
                                }
                            }
                            
                            // Apply rule logic
                            if ($location_matches_rule) {
                                if ($rule_logic === 'block_from') {
                                    // Block from: restrict if location matches
                                    $is_restricted = true;
                                    $restriction_reason = $restriction_type;
                                    $this->log(sprintf('RESTRICTION TRIGGERED (Block): %s', $restriction_reason), 'warning');
                                    break;
                                } else {
                                    // Allow only: this rule allows this location, continue checking other rules
                                    $this->log(sprintf('Location allowed by rule: %s', $restriction_type), 'info');
                                }
                            } else {
                                if ($rule_logic === 'allow_only') {
                                    // Allow only: restrict if location doesn't match
                                    $is_restricted = true;
                                    /* translators: %1$s: Rule name */
                                    $restriction_reason = sprintf(__('Location not in allowed list for rule: %1$s', 'ship-restrict'), isset($rule['name']) ? $rule['name'] : '');
                                    $this->log(sprintf('RESTRICTION TRIGGERED (Allow Only): %s', $restriction_reason), 'warning');
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if ($is_restricted) {
                $restricted[] = array(
                    'product_name' => $product_name,
                    'product_id' => $product_id,
                    'reason' => str_replace('{product}', $product_name, $message_template_to_use),
                );
            }
        }
        return $restricted;
    }

    /**
     * Check cart items for restrictions during checkout validation.
     */
    public function spsr_cart_restriction_notice() {
        // Get the validation errors - WooCommerce checkout validation doesn't pass WP_Error object
        // We need to use wc_add_notice instead

        $restricted = $this->get_restricted_cart_items();
        if (!empty($restricted)) {
            $this->log('Found restricted items during checkout: ' . count($restricted), 'info');
            
            // Use a general header notice, then list the specific items
            $header_notice = __('Some items in your cart cannot be shipped to your address:', 'ship-restrict');
            
            $msg = '<ul>'; // Start with only the list
            foreach ($restricted as $item) {
                // Directly use the pre-formatted reason which now includes the product name
                $msg .= sprintf('<li>%s</li>', esc_html($item['reason']));
                $this->log('Restricted item: ' . $item['product_name'] . ' - ' . $item['reason'], 'warning');
            }
            $msg .= '</ul>';

            // Add the restriction message as a checkout validation error
            wc_add_notice($header_notice . $msg, 'error');
        } else {
            $this->log('No restricted items found during checkout validation', 'info');
        }
    }

    /**
     * Modern cart validation using Store API (recommended approach)
     * 
     * @param WP_Error $errors Error object to add validation errors to
     * @param WC_Cart $cart   Cart object
     */
    public function validate_cart_restrictions($errors, $cart) {
        // Prevent duplicate validation messages
        if ($this->validation_run) {
            return;
        }
        $this->validation_run = true;

        $this->log('Running modern cart validation via Store API', 'info');

        $restricted = $this->get_restricted_cart_items();
        
        if (!empty($restricted)) {
            $this->log('Found ' . count($restricted) . ' restricted items in cart', 'warning');
            
            $header_notice = __('Some items in your cart cannot be shipped to your address:', 'ship-restrict');
            $msg = '<ul>';
            
            foreach ($restricted as $item) {
                $msg .= sprintf('<li>%s</li>', esc_html($item['reason']));
                $this->log('Restricted item: ' . $item['product_name'] . ' - ' . $item['reason'], 'warning');
            }
            
            $msg .= '</ul>';

            // Add error to the WP_Error object (check if not already added)
            if (!$errors->get_error_message('shipping_restriction')) {
                $errors->add('shipping_restriction', $header_notice . $msg);
            }
        } else {
            $this->log('No restricted items found in cart validation', 'info');
        }
    }

    /**
     * Legacy cart validation (fallback for older WooCommerce versions)
     */
    public function legacy_cart_validation() {
        // Prevent duplicate validation messages
        if ($this->validation_run) {
            return;
        }
        $this->validation_run = true;

        $this->log('Running legacy cart validation', 'info');

        $restricted = $this->get_restricted_cart_items();
        
        if (!empty($restricted)) {
            $this->log('Found ' . count($restricted) . ' restricted items via legacy validation', 'warning');
            
            $header_notice = __('Some items in your cart cannot be shipped to your address:', 'ship-restrict');
            $msg = '<ul>';
            
            foreach ($restricted as $item) {
                $msg .= sprintf('<li>%s</li>', esc_html($item['reason']));
                $this->log('Restricted item: ' . $item['product_name'] . ' - ' . $item['reason'], 'warning');
            }
            
            $msg .= '</ul>';

            // Use wc_add_notice for legacy validation (check if notice already exists)
            $full_notice = $header_notice . $msg;
            if (!wc_has_notice($full_notice, 'error')) {
                wc_add_notice($full_notice, 'error');
            }
        } else {
            $this->log('No restricted items found in legacy validation', 'info');
        }
    }

    /**
     * Log message using WooCommerce logger
     *
     * @param string $message Message to log
     * @param string $level Log level (info, warning, error)
     */
    private function log($message, $level = 'info') {
        if (function_exists('wc_get_logger')) {
            $logger = wc_get_logger();
            $context = array('source' => 'ship-restrict');
            
            switch ($level) {
                case 'error':
                    $logger->error($message, $context);
                    break;
                case 'warning':
                    $logger->warning($message, $context);
                    break;
                default:
                    $logger->info($message, $context);
            }
        }
    }

    /**
     * Get cached value
     *
     * @param string $key Cache key
     * @return mixed Cached value or false if not found
     */
    private function get_cache($key) {
        return get_transient('spsr_cache_' . $key);
    }

    /**
     * Set cache value
     *
     * @param string $key Cache key
     * @param mixed $value Value to cache
     * @param int|null $expiration Expiration time in seconds (default: 15 minutes)
     * @return bool True if set successfully, false otherwise
     */
    private function set_cache($key, $value, $expiration = null) {
        if (null === $expiration) {
            $expiration = 15 * MINUTE_IN_SECONDS;
        }
        return set_transient('spsr_cache_' . $key, $value, $expiration);
    }

    /**
     * Clear cache
     *
     * @param string|null $key Specific cache key to clear, or null to clear all
     */
    private function clear_cache($key = null) {
        if ($key) {
            delete_transient('spsr_cache_' . $key);
        } else {
            // Clear all SPSR caches (implement if needed in the future)
            // This would require tracking all cache keys or using a different approach
        }
    }

    /**
     * Check if API requests are rate limited
     *
     * @return bool True if rate limited, false otherwise
     */
    private function is_rate_limited() {
        $transient_key = 'spsr_api_rate_limit';
        $attempts = get_transient($transient_key);
        
        if (false === $attempts) {
            set_transient($transient_key, 1, SPSR_RATE_LIMIT_WINDOW);
            return false;
        }
        
        if ($attempts >= SPSR_RATE_LIMIT_MAX) {
            return true;
        }
        
        set_transient($transient_key, $attempts + 1, SPSR_RATE_LIMIT_WINDOW);
        return false;
    }

    /**
     * Get or generate a unique device identifier for this site
     *
     * @return string
     */
    private function get_device_identifier() {
        $device_id = get_option('spsr_device_id');
        if (!$device_id) {
            $device_id = wp_generate_uuid4();
            update_option('spsr_device_id', $device_id);
        }
        return $device_id;
    }

    /**
     * Validate or activate license with KeyForge
     *
     * @param string $license_key
     * @param bool $activate
     * @return array [ 'valid' => bool, 'error' => string, 'product_id' => string ]
     */
    private function keyforge_validate_license($license_key, $activate = false) {
        // Don't validate empty license keys
        if (empty($license_key)) {
            return array(
                'valid' => false,
                'error' => '',
                'product_id' => $this->get_product_identifier()
            );
        }
        
        // Check rate limiting
        if ($this->is_rate_limited()) {
            return array(
                'valid' => false,
                'error' => 'Too many validation attempts. Please try again in 5 minutes.',
                'product_id' => $this->get_product_identifier()
            );
        }
        
        $device_id = $this->get_device_identifier();
        $site_name = get_bloginfo('name');
        $site_url = home_url();
        $product_id = $this->get_product_identifier();
        $endpoint = $activate
            ? 'https://keyforge.dev/api/v1/public/licenses/activate'
            : 'https://keyforge.dev/api/v1/public/licenses/validate';
        $body = array(
            'licenseKey' => $license_key,
            'productId' => $product_id,
            'deviceIdentifier' => $device_id,
        );
        if ($activate) {
            $device_name = $site_name . ' (' . $site_url . ')';
            // Truncate device name to 64 characters max (API requirement)
            if (strlen($device_name) > 64) {
                $device_name = substr($device_name, 0, 61) . '...';
            }
            $body['deviceName'] = $device_name;
        }
        $args = array(
            'headers' => array('Content-Type' => 'application/json'),
            'body' => wp_json_encode($body),
            'timeout' => 10,
        );
        $response = wp_remote_post($endpoint, $args);
        if (is_wp_error($response)) {
            return array('valid' => false, 'error' => 'Could not reach license server.', 'product_id' => $product_id);
        }
        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // Accept any 2xx code as success response format.
        if ($code < 200 || $code >= 300) {
            $err = 'License server error (' . $code . ').';
            if (is_array($data) && isset($data['message'])) {
                $err .= ' ' . $data['message'];
            }
            return array('valid' => false, 'error' => $err, 'product_id' => $product_id);
        }
        if (!is_array($data)) {
            // Some endpoints (e.g., activate) may return empty body; treat as success.
            return array('valid' => true, 'error' => '', 'product_id' => $product_id);
        }
        if ($activate) {
            // Activation returns 200 on success, no isValid field
            return array('valid' => true, 'error' => '', 'product_id' => $product_id);
        }
        if ((isset($data['isValid']) && $data['isValid']) || (isset($data['valid']) && $data['valid'])) {
            return array('valid' => true, 'error' => '', 'product_id' => $product_id);
        }
        return array('valid' => false, 'error' => isset($data['message']) ? $data['message'] : 'License invalid.', 'product_id' => $product_id);
    }
    
    /**
     * Clear product restriction cache
     */
    public function clear_product_cache() {
        wp_cache_delete('spsr_states_products_' . md5('states_query'), 'spsr');
        wp_cache_delete('spsr_cities_products_' . md5('cities_query'), 'spsr');
        wp_cache_delete('spsr_zip_products_' . md5('zip_query'), 'spsr');
    }
    
    /**
     * Clear product restriction cache when meta changes
     * 
     * @param int    $meta_id    ID of the metadata entry to update.
     * @param int    $object_id  Object ID.
     * @param string $meta_key   Meta key.
     * @param mixed  $meta_value Meta value.
     */
    public function clear_product_cache_on_meta_change($meta_id, $object_id, $meta_key, $meta_value) {
        $restriction_keys = array('_restricted_states', '_restricted_cities', '_restricted_state_cities', '_restricted_zip_codes');
        if (in_array($meta_key, $restriction_keys, true)) {
            $this->clear_product_cache();
        }
    }
}

/**
 * Main plugin instance
 *
 * @return APSR_Pro
 */
function APSR_PRO() {
    return APSR_Pro::instance();
}

// Initialize the plugin
add_action('plugins_loaded', 'APSR_PRO');

// Use the proper checkout validation hook
add_action('woocommerce_checkout_process', array(APSR_Pro::instance(), 'spsr_cart_restriction_notice'), 5);

// Fallback: print notices in footer if not already rendered (useful for Cart page)
add_action('wp_footer', function() {
    // Add early exit if functions don't exist
    if (!function_exists('is_checkout') || !function_exists('is_cart')) {
        return;
    }
    if (is_checkout() || is_cart()) {
        wc_print_notices();
    }
}, 99);

// Add JavaScript for variation city management
add_action('admin_footer', function() {
    global $pagenow, $post_type;
    if (($pagenow === 'post.php' || $pagenow === 'post-new.php') && $post_type === 'product') {
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Initialize Select2 for variation state selectors.
            function initVariationSelect2() {
                if ( $.fn.select2 ) {
                    $( '.spsr-select2-states' ).not( '.select2-hidden-accessible' ).select2({
                        placeholder: '<?php echo esc_js( __( 'Select states...', 'ship-restrict' ) ); ?>',
                        allowClear: true,
                        width: '100%'
                    });
                }
            }

            // Initialize on page load.
            initVariationSelect2();

            // Re-initialize when WooCommerce loads variations.
            $( document ).on( 'woocommerce_variations_loaded woocommerce_variations_added', function() {
                initVariationSelect2();
            });

            var variationCityIndexes = {};

            // Initialize indexes for each variation
            $('.spsr-variation-cities-container').each(function() {
                var variationId = $(this).data('variation-id');
                variationCityIndexes[variationId] = $(this).find('.spsr-state-city-pair').length;
            });
            
            // Add city for variations
            $(document).on('click', '.spsr-add-variation-city', function() {
                var variationId = $(this).data('variation-id');
                if (!variationCityIndexes[variationId]) {
                    variationCityIndexes[variationId] = 1;
                }
                
                var index = variationCityIndexes[variationId];
                var container = $('#spsr-variation-state-cities-' + variationId);
                
                var newPair = '<div class="spsr-state-city-pair" style="margin-bottom: 10px;">' +
                    '<select name="_restricted_state_cities[' + variationId + '][' + index + '][state]" style="width: 120px; margin-right: 10px;">' +
                    '<option value=""><?php esc_html_e('Select State', 'ship-restrict'); ?></option>';
                <?php 
                $us_states = function_exists('WC') ? WC()->countries->get_states('US') : array();
                foreach ($us_states as $code => $label) { 
                ?>
                newPair += '<option value="<?php echo esc_js($code); ?>"><?php echo esc_js($code); ?></option>';
                <?php } ?>
                newPair += '</select>' +
                    '<input type="text" name="_restricted_state_cities[' + variationId + '][' + index + '][city]" placeholder="<?php esc_attr_e('City name', 'ship-restrict'); ?>" style="width: 200px; margin-right: 10px;">' +
                    '<button type="button" class="button spsr-remove-variation-city"><?php esc_html_e('Remove', 'ship-restrict'); ?></button>' +
                    '</div>';
                    
                container.append(newPair);
                variationCityIndexes[variationId]++;
                updateVariationRemoveButtons(container);
            });
            
            // Remove city for variations
            $(document).on('click', '.spsr-remove-variation-city', function() {
                var container = $(this).closest('.spsr-variation-cities-container');
                $(this).closest('.spsr-state-city-pair').remove();
                updateVariationRemoveButtons(container);
            });
            
            function updateVariationRemoveButtons(container) {
                var pairs = container.find('.spsr-state-city-pair');
                if (pairs.length > 1) {
                    container.find('.spsr-remove-variation-city').show();
                } else {
                    container.find('.spsr-remove-variation-city').hide();
                }
            }
            
            // Initialize all variation containers
            $('.spsr-variation-cities-container').each(function() {
                updateVariationRemoveButtons($(this));
            });
        });
        </script>
        <?php
    }
});

// Add Settings link to plugin row actions
function shiprestrict_plugin_action_links($actions) {
    if (current_user_can('manage_woocommerce')) {
        $settings_url = admin_url('admin.php?page=spsr-settings');
        $settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'ship-restrict') . '</a>';
        array_unshift($actions, $settings_link);
    }
    return $actions;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'shiprestrict_plugin_action_links');
